/************************************************************************************
FronTier is a set of libraries that implements differnt types of Front Traking algorithms.
Front Tracking is a numerical method for the solution of partial differential equations 
whose solutions have discontinuities.  


Copyright (C) 1999 by The University at Stony Brook. 
 

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

******************************************************************************/


/*
*			fscat3d1.c
*
*	Copyright 1999 by The University at Stony Brook, All rights reserved.
*
*/

#if defined(THREED)

#define DEBUG_STRING    "fscatter"
#include <front/fdecs.h>

struct _POINT_LIST {
	POINT              *p;
	HYPER_SURF         *hs;
	HYPER_SURF_ELEMENT *hse;
	struct _POINT_LIST *prev, *next;
};
typedef struct _POINT_LIST POINT_LIST;

struct _POINT_LIST_STORE {
	POINT_LIST *pl;
	int        len;
};
typedef struct _POINT_LIST_STORE POINT_LIST_STORE;


	/* LOCAL Function Declarations */
LOCAL	POINT_LIST	*set_point_list(TRI**,int,HYPER_SURF*,
					POINT_LIST_STORE*);
LOCAL	TRI*	find_following_null_tri(TRI*,POINT**,int*,ANGLE_DIRECTION);
LOCAL	bool	add_matching_pt_to_hash_table(TRI**,TRI**,int,int,SURFACE*,
					      SURFACE*,P_LINK*,int);
LOCAL	bool	buffer_extension3d1(INTERFACE*,INTERFACE*,int,int,bool);
LOCAL	bool    f_intfc_communication3d1(Front*);
LOCAL	bool	match_tris_at_subdomain_bdry(SURFACE*,SURFACE*,TRI**,TRI**,
	                                     int,int);
LOCAL	bool	match_two_tris(TRI*,TRI*);
LOCAL	bool	null_side_on_surface(SURFACE*,TRI**,int*);
LOCAL	bool	tri_cross_line(TRI*,float,int);
LOCAL	bool	tri_out_domain1(TRI*,float*,float*,int,int);
LOCAL	int	append_adj_intfc_to_buffer1(INTERFACE*,INTERFACE*,
					   RECT_GRID*,int,int);
//#bjet2
LOCAL	int	append_adj_intfc_to_buffer1_old(INTERFACE*,INTERFACE*,
					   RECT_GRID*,int,int);
LOCAL	int	append_buffer_surface1(SURFACE*,SURFACE*,RECT_GRID*,int,int,
				      P_LINK*,int);
LOCAL	void	clip_intfc_at_grid_bdry1(INTERFACE*);
//#bjet2
LOCAL	bool	tri_bond_out_domain(TRI*,float*,float*,int,int);
LOCAL	bool	tri_bond_test(TRI*,float*,float*,int,int);
LOCAL	bool	tri_bond_cross_line(TRI*,float,int);
LOCAL	bool	tri_bond_cross_test(TRI*,float,int);
LOCAL	void	copy_tri_state_to_btri(BOND_TRI*,BOND*,ORIENTATION,INTERFACE *);
LOCAL	void	merge_point_pointers_at_subdomain_bdry(TRI**,TRI**,
						       int,P_LINK*,int);
LOCAL	void	shift_interface(INTERFACE*,float,int);
LOCAL	void	strip_curve_from_surf(CURVE*,SURFACE*,ORIENTATION);
LOCAL	void	synchronize_tris_at_subdomain_bdry(TRI**,TRI**,int,P_LINK*,int);
LOCAL	INTERFACE	*cut_buf_interface1(INTERFACE*,int,int,int*,int*);
LOCAL   bool    find_null_side_loop(INTERFACE*,TRI*,int,TRI**,int*);
LOCAL	COMPONENT buffer_component(INTERFACE*,int,int);
//#bjet2
LOCAL  void    test_curve_link(CURVE *);

LOCAL	double	tol1[MAXD]; //TOLERANCE
LOCAL   double  tol_pt[MAXD]; //TOLERANCE for point matching

#define MAX_NULL_SIDE      8000

//#bjet2
LOCAL  void    test_curve_link(CURVE *c)
{
BOND    *b, *bn;

	if(c->first->prev != NULL || c->last->next != NULL)
	    printf("#test_curve_link, first or last != NULL.\n");
	
	for(b=c->first; b; b=b->next)
	{
	    bn = b->next;
	    if(bn != NULL)
	    {
	        if(bn->start != b->end)
	    	    printf("#test_curve_link, point error %d %d\n", 
		        bn->start, b->end);
		if(bn->prev != b)
	    	    printf("#test_curve_link, link error %d %d %d\n", 
		        b, bn, bn->prev);
	    }
	}
}

LOCAL	bool	deact_default_comp = NO;

void	set_default_comp(bool);
void	set_default_comp(bool flag)
{
	deact_default_comp = flag;
}

void	delete_zero_tris(Front *);

/*ARGSUSED*/
EXPORT bool f_intfc_communication3d(
	Front		*fr)
{
	if (pp_numnodes() > 1 && deact_default_comp == NO)
	    communicate_default_comp(fr);

	if (interface_reconstructed(fr->interf))
	    return f_intfc_communication3d2(fr);
	else
	{
	    bool status;

	    status = f_intfc_communication3d1(fr);
	    delete_zero_tris(fr);

	    return status;
	}

}	/* end f_intfc_communication3d */

IMPORT void sep_common_pt_for_open_bdry(INTERFACE*);
void	 cut_buffer_tris_from_intfc(INTERFACE*, int, int);
int	cut_buffer_tris(SURFACE*, RECT_GRID*, int, int);
void	sep_common_pt_for_ref_bdry(INTERFACE *intfc, int, int);
void	make_ref_strip(float*, float*, INTERFACE*);
void	extend_long_ref_side(float*,float*,int, INTERFACE*,Front*);
void	cut_intfc_along_bdry(int, int, INTERFACE*);
void	flag_buffer_tris(int, int, INTERFACE*);
void   clip_intfc_in_dir(INTERFACE*, int, int);
void	reflect_curves_on_intfc(INTERFACE*,float*,float*);
void	set_ref_append(bool);

void	set_open_bdry_flag(bool);

void	construct_reflect_bdry(
	Front		*fr)
{
	INTERFACE    *intfc = fr->interf, *buf_intfc;
	INTERFACE    *cur_intfc = current_interface();
	RECT_GRID    *gr = fr->rect_grid;
	SURFACE	     **s;
	float        *U = gr->U, *L = gr->L;
	float        *nor, p[3];
	int	     me[MAXD], him[MAXD];
	int	     i, j, k;
	int	     dim = intfc->dim;
	bool	     status;
	static float nors[] = {  1.0,  0.0,  0.0,
			         0.0,  1.0,  0.0,
			         0.0,  0.0,  1.0,
			        -1.0,  0.0,  0.0,
			         0.0, -1.0,  0.0,
			         0.0,  0.0, -1.0};

	DEBUG_ENTER(construct_reflect_bdry)

	set_current_interface(intfc);
	strip_subdomain_bdry_curves(intfc);

	for (i = 0; i < dim; ++i)
	{
	    for (j = 0; j < 2; ++j)
	    {
		for (k = 0; k < dim; ++k)
		    him[k] = me[k] = pp_mynode();

		if (rect_boundary_type(intfc,i,j) != REFLECTION_BOUNDARY)
		    continue;


		//TMP deal with open bdry
		//if(debugging("opbdz"))
		if((i == 2 && j == 0) || (i == 0 && j == 1))
		    set_open_bdry_flag(YES);
		else
		    set_open_bdry_flag(NO);

		clip_intfc_in_dir(intfc, i, j);
		buf_intfc = cut_buf_interface1(intfc,i,j,me,him);
		
		    if(NO && i == 0 && j ==0 && pp_mynode() == 44)
		    {
	    		printf("#cut_ref -2\n");
			tecplot_interface("cut_ref_buf_intfc_2.plt", buf_intfc);
	   	    }

	
		nor = nors + 3*i + 9*j;
		p[i] = (j > 0) ? U[i] : L[i];
		for(k = 1; k < dim; ++k)
		    p[(k+i)%dim] = 0.5*(U[(k+i)%dim] + L[(k+i)%dim]);
		   
		if(debugging("cut_ref"))
		{
		    if(NO && i == 0 && j ==1 && pp_mynode() == 1)
		    {
	    		printf("#cut_ref 0\n");
			tecplot_interface("cut_ref_intfc_bf.plt", intfc);
			//tecplot_interface("cut_ref_buf_intfc.plt", buf_intfc);
	   	    }

		    cut_intfc_along_bdry(i, j, intfc);
		    cut_intfc_along_bdry(i, j, buf_intfc);
	
		    if(NO && i == 0 && j ==1 && pp_mynode() == 1)
		    {
	    		printf("#cut_ref 1\n");
			tecplot_interface("cut_ref_intfc.plt", intfc);
			//tecplot_interface("cut_ref_buf_intfc.plt", buf_intfc);
	   	    }

		    flag_buffer_tris(i, j, intfc);
		    flag_buffer_tris(i, j, buf_intfc);

		}
		else
		{
		    cut_buffer_tris_from_intfc(intfc, i, j);
		    cut_buffer_tris_from_intfc(buf_intfc, i, j);
		}
		    
		    if(i == 0 && j ==0 && pp_mynode() == 44 && NO)
		    {
	    		printf("#cut_ref -1\n");
			//tecplot_interface("cut_ref_buf_intfc_1.plt", buf_intfc);
			
			null_sides_are_consistent();
			check_print_intfc("After cut_buf", "cut_intfc", 'g', 
					  intfc, 1, -1, NO);

			null_sides_are_consistent();
			check_print_intfc("After cut_buf buf", "cut_intfc_buf", 'g', 
					  buf_intfc, 1, -1, YES);
	   	    }


		sep_common_pt_for_ref_bdry(intfc, i, j);
		sep_common_pt_for_ref_bdry(buf_intfc, i, j);
		  
		//extend_long_ref_side(p,nor,i,intfc,fr);
		//extend_long_ref_side(p,nor,i,buf_intfc,fr);

		reflect_interface(buf_intfc, p, nor);
		reflect_curves_on_intfc(buf_intfc, p, nor);
	
		    if(NO && i == 0 && j ==0 && pp_mynode() == 44)
		    {
	    		printf("#cut_ref -11\n");
			//tecplot_interface("cut_ref_buf_intfc_1.plt", buf_intfc);
			
			null_sides_are_consistent();
			check_print_intfc("After cut_buf buf", "cut_intfc_bufb", 'g', 
					  buf_intfc, 1, 1, NO);
	   	    }

		make_ref_strip(p, nor, intfc);
		make_ref_strip(p, nor, buf_intfc);
	
		    if(i == 0 && j ==0 && pp_mynode() == 44 && NO)
		    {
	    		printf("#cut_ref -12\n");
			//tecplot_interface("cut_ref_buf_intfc_1.plt", buf_intfc);
	
			null_sides_are_consistent();
			check_print_intfc("After cut_buf buf", "cut_intfcc", 'g', 
					  intfc, 1, 1, NO);
		
			null_sides_are_consistent();
			check_print_intfc("After cut_buf buf", "cut_intfc_bufc", 'g', 
					  buf_intfc, 1, 1, NO);
	   	    }

	   
		set_current_interface(intfc);
		    

		status = FUNCTION_SUCCEEDED;
		set_ref_append(YES);
		status = buffer_extension3d1(intfc,buf_intfc,i,j,status);
		set_ref_append(NO);

		    if(NO && i == 0 && j ==0 && pp_mynode() == 4)
		    {
	    		printf("#cut_ref -13\n");
			//tecplot_interface("cut_ref_buf_intfc_1.plt", buf_intfc);
	
			null_sides_are_consistent();
			check_print_intfc("After cut_buf buf", "intfcd", 'g', 
					  intfc, 1, 1, NO);
	   	    }
                  
		if (!status)
                {
		    (void) printf("WARNING in construct_reflect_bdry "
			      "buffer_extension3d1 failed for "
                              "i = %d, j = %d \n", i, j);
                    clean_up(ERROR);
                }

		(void) delete_interface(buf_intfc);
		set_current_interface(intfc);

                for (s = intfc->surfaces; s && *s; ++s)
                {
                    if (no_tris_on_surface(*s))
                    {
                        (void) delete_surface(*s);
                        --s;
                    }
                }
                if(intfc->surfaces != NULL && *(intfc->surfaces) == NULL)
                    intfc->surfaces = NULL;
                if(intfc->surfaces == NULL)
                {
                    printf("no tris, exit construct_reflect_bdry.\n");
                    goto exit_ref;
                }

	    }	//for j=0, 1, two direction communication.
	    reset_intfc_num_points(intfc);
	}

exit_ref: 
	set_open_bdry_flag(NO);

	set_current_interface(cur_intfc);
	DEBUG_LEAVE(construct_reflect_bdry)

}

void    move_surf_points_on_plane(
	SURFACE		*surf,
	SURFACE		*surf1,
	int		dir,
	int		nb,
	INTERFACE	*intfc)
{
	RECT_GRID	*gr = computational_grid(intfc);
	float		crx_coord, *nor, v[3], len;
	TRI		*tri, *tri1;
	POINT		*p0, *p;
	int		i;
	static float nors[] = {  1.0,  0.0,  0.0,
			         0.0,  1.0,  0.0,
			         0.0,  0.0,  1.0,
			        -1.0,  0.0,  0.0,
			         0.0, -1.0,  0.0,
			         0.0,  0.0, -1.0};


	nor = nors + 3*dir + 9*nb;
	crx_coord = (nb == 0) ? gr->L[dir] : gr->U[dir];

	//surf  old surf
	//surf1 new surf
	for (tri=first_tri(surf), tri1=first_tri(surf1); 
	    !at_end_of_tri_list(tri,surf) && !at_end_of_tri_list(tri1,surf1); 
	    tri=tri->next, tri1=tri1->next)
	{
	    if (tri_cross_line(tri,crx_coord,dir) == YES) 
	    {
		for(i=0; i<3; i++)
		{
		    p0 = Point_of_tri(tri)[i];
		    if(sorted(p0))
			continue;
		    
		    sorted(p0) = YES;
		    p = Point_of_tri(tri1)[i];
		    difference(Coords(p0), Coords(p), v, 3);
		    len = Dot3d(v, nor);
		    Coords(p)[dir] += len*nor[dir];
		}
	    }
	}
}

void	move_intfc_points_on_plane(INTERFACE*,INTERFACE*);

void	move_intfc_points_on_plane(
	INTERFACE	*intfc,
	INTERFACE	*intfc_new)
{
	int		i, j;
	SURFACE		**s_old, **s_new;

	for(i=0; i<3; i++)
	    for(j=0; j<2; j++)
	    {
		if(rect_boundary_type(intfc,i,j) != REFLECTION_BOUNDARY)
		    continue;
		next_point(intfc, NULL, NULL, NULL);
		
		for (s_old = intfc->surfaces, s_new = intfc_new->surfaces;
		     s_old && *s_old && s_new && *s_new; ++s_old, ++s_new)
		    move_surf_points_on_plane(*s_old, *s_new, i, j, intfc);
	    }
}

LOCAL	bool f_intfc_communication3d1(
	Front		*fr)
{
	INTERFACE    *intfc = fr->interf;
	INTERFACE    *adj_intfc[2], *sav_intfc, *buf_intfc;
	PP_GRID	     *pp_grid = fr->pp_grid;
	RECT_GRID    *gr = fr->rect_grid;
	bool	     sav_copy;
	bool      status = FUNCTION_SUCCEEDED;
	float        *U = gr->U, *L = gr->L;
	float        *nor, p[3];
	float        T;
	int	     me[MAXD], him[MAXD];
	int	     myid, dst_id;
	int	     *G;
	int	     i, j, k;
	int	     dim = intfc->dim;
	static float nors[] = {  1.0,  0.0,  0.0,
			         0.0,  1.0,  0.0,
			         0.0,  0.0,  1.0,
			        -1.0,  0.0,  0.0,
			         0.0, -1.0,  0.0,
			         0.0,  0.0, -1.0};

	DEBUG_ENTER(f_intfc_communication3d1)

	set_floating_point_tolerance1(fr->rect_grid->h);
	sav_copy = copy_intfc_states();
	sav_intfc = current_interface();
	set_copy_intfc_states(YES);

	myid = pp_mynode();
	G = pp_grid->gmax;
	find_Cartesian_coordinates(myid,pp_grid,me);

	if (DEBUG)
	{
	    (void) printf("myid = %d, ",myid);
	    print_int_vector("me = ",me,dim,"\n");
	    print_PP_GRID_structure(pp_grid);
	    (void) printf("Input interface:\n");
	    print_interface(intfc);
	}

	construct_reflect_bdry(fr);

	if(fr->step == -1)
	    add_to_debug("out_surf");
		
		/* Extend interface in three directions */

	clip_intfc_at_grid_bdry1(intfc);
	
	//null_sides_are_consistent();
	//check_print_front("After clip intfc", "clip_af", 'g', 
	//		  intfc, 1, 1, YES);

	pp_gsync();

	for (i = 0; i < dim; ++i)
	{
	    adj_intfc[0] = adj_intfc[1] = NULL;
	    for (j = 0; j < 2; ++j)
	    {
	    	pp_gsync();

		for (k = 0; k < dim; ++k)
		    him[k] = me[k];

		//when using reflect boundary, the strip can be outside the domain.
		//must clip.
		//clip_intfc_in_dir(intfc, i, j);
		
		if (rect_boundary_type(intfc,i,j) == SUBDOMAIN_BOUNDARY)
		{
		    him[i] = (me[i] + 2*j - 1 + G[i])%G[i];
		    dst_id = domain_id(him,G,dim);
		    
		    buf_intfc = cut_buf_interface1(intfc,i,j,me,him);
		    
		    if ((j == 0) && (me[i] == 0))
		    {
			T = gr->GU[i] - gr->GL[i];
	                shift_interface(buf_intfc,T,i);
		    }
		    else if ((j == 1) && (me[i] == (G[i]-1)))
		    {
			T = gr->GL[i] - gr->GU[i];
	                shift_interface(buf_intfc,T,i);
		    }
		    if (dst_id != myid)
		    {
		    	send_interface(buf_intfc,dst_id);
		        (void) delete_interface(buf_intfc);
		    }
		    else
		        adj_intfc[(j+1)%2] = buf_intfc;
		}
		else if (rect_boundary_type(intfc,i,j) == REFLECTION_BOUNDARY)
		{
		    adj_intfc[j] = NULL;
		    set_current_interface(intfc);
		}

		if (rect_boundary_type(intfc,i,(j+1)%2) == SUBDOMAIN_BOUNDARY)
		{
		    him[i] = (me[i] - 2*j + 1 + G[i])%G[i];
		    dst_id = domain_id(him,G,dim);
		    if (dst_id != myid)
			adj_intfc[(j+1)%2] = receive_interface(dst_id);
		}
	    }
	    for (j = 0; j < 2; ++j)
	    {
		status = FUNCTION_SUCCEEDED;
		if (adj_intfc[j] != NULL)
		{
		  	if(NO)
			//if(debugging("cut_ref"))
			//if(pp_mynode()==8 || pp_mynode() == 12)
		        {
	    		    char s[40];

	    		    printf("#out_surf check %d %d\n", i, j);
	    		    
			    sprintf(s, "buf_intfc%d_%d_%d.plt", 
			    		pp_mynode(), i, j);
			    printf("#tec out %s\n", s);
			    tecplot_interface(s, intfc);
			    
			    sprintf(s, "buf_adj_intfc%d_%d_%d.plt", 
			    		pp_mynode(), i, j);
			    printf("#tec out adj %s\n", s);
			    tecplot_interface(s, adj_intfc[j]);
			 
			    printf("#check intfc consistence\n");
			    null_sides_are_consistent();
			    if(!f_consistent_interface(intfc))
			    {
			        printf("#extension bf intfc incon\n");
			    }
			    else
			        printf("#extension bf intfc con\n");

			    null_sides_are_consistent();
			    if(!f_consistent_interface(adj_intfc[j]))
			    {
			        printf("#extension bf adj_intfc incon\n");
			    }
			    else
			        printf("#extension bf adj_intfc con\n");
			}
		    status = buffer_extension3d1(intfc,adj_intfc[j],i,j,status);
		    //#bjet2
		    if (!status)
                    {
		        (void) printf("WARNING in f_intfc_communication3d1 "
				      "buffer_extension3d1 failed for "
                                        "i = %d, j = %d \n", i, j);
                        //clean_up(ERROR);
                    }

		    (void) delete_interface(adj_intfc[j]);
		    set_current_interface(intfc);
		}    //if (adj_intfc[j] != NULL)
		
		//surface in this direction can not mathch, return 
		status = pp_min_status(status);

		if(!status)
		    goto comm_exit;

	    }	//for j=0, 1, two direction communication.

	    reset_intfc_num_points(intfc);
	}

	if (status == FUNCTION_SUCCEEDED)
	{
		
	    sep_common_pt_for_open_bdry(intfc);

	    install_subdomain_bdry_curves(intfc);

	    //print_interface(intfc);
	    reset_intfc_num_points(intfc);
	    if (DEBUG)
	    {
	    	(void) printf("Final intfc:\n");
	    	print_interface(intfc);
	    }
	}

comm_exit:

	set_copy_intfc_states(sav_copy);
	set_current_interface(sav_intfc);
	DEBUG_LEAVE(f_intfc_communication3d1)
	return status;
}	/*end f_intfc_communication3d1 */

#define	MAX_SUBDOMAIN_TRIS	6000
LOCAL	bool find_ending_null_side(TRI*,int,TRI**,int*);

EXPORT void install_subdomain_bdry_curves(
	INTERFACE	*intfc)
{
	BOND	 *b;
	BOND_TRI *btri;
	CURVE	 *curve, **c;
	NODE	 *ns, *ne, **n, **n1;
	POINT	 *p, *ps, *pe;
	TRI	 *tri_start, *start_tri, *null_tris[MAX_SUBDOMAIN_TRIS];
	SURFACE	 **s;
	Locstate sl, sr;
	bool  	 sav_intrp, dup_nodes;
	int	 side_start, start_side, ntris, i;
	int	 dim = intfc->dim;

	DEBUG_ENTER(install_subdomain_bdry_curves)
	
	sav_intrp = interpolate_intfc_states(intfc);
	interpolate_intfc_states(intfc) = NO;
	
	for (s = intfc->surfaces; s && *s; ++s)
	{
	    while (null_side_on_surface(*s,&start_tri,&start_side))
	    {
		find_ending_null_side(start_tri,start_side,
				&tri_start,&side_start);
		
		ps = Point_of_tri(tri_start)[side_start];
	    	ns = make_node(ps);
		pe = Point_of_tri(tri_start)[Next_m3(side_start)];
		ne = make_node(pe);
		curve = make_curve(NO_COMP,NO_COMP,ns,ne);

		hsbdry_type(curve) = SUBDOMAIN_HSBDRY;
	    	install_curve_in_surface_bdry(*s,curve,POSITIVE_ORIENTATION);
	    	
		//printf("#c %d | %d  %d | %d  %d\n", curve_number(curve), 
		//	ns, ne, ns->posn, ne->posn);
		
		null_tris[0] = tri_start;
		ntris = 1;

	    	b = curve->first;
		while((tri_start = find_following_null_tri(tri_start,&p,
					&side_start,CLOCKWISE)) != NULL)
		{
		    if (insert_point_in_bond(ns->posn,b,curve) !=
			FUNCTION_SUCCEEDED)
		    {
			screen("ERROR in install_subdomain_bdry_curves(), "
		               "insert_point_in_bond() failed\n");
			clean_up(ERROR);
		    }
		    
		    ns->posn = b->start = p;
		    set_bond_length(b,dim);
	
		    null_tris[ntris] = tri_start;
		    ntris++;
		    if(ntris >= MAX_SUBDOMAIN_TRIS)
		    {
			printf("ERROR install_subdomain_bdry_curves "
			       "too many subdomain tris.\n");
			clean_up(ERROR);
		    }
	    
		    if (ns->posn == ne->posn) //Closed loop formed
		    {
			change_node_of_curve(curve,POSITIVE_ORIENTATION,ne);
			if(!delete_node(ns))
			{
			    printf("ERROR install_subdomain_bdry_curves "
			    	   "can not delete ns node for a loop.\n");
			    print_node(ns);
			    clean_up(ERROR);
			}
			break;
		    }
		}
		
		//for(i=0, b=curve->first; b!=NULL; b=b->next, i++)
		//{
		//    printf("%d  %d %d\n", b, b->start, b->end);
		//    print_tri(null_tris[i], intfc);
		//}

		for(i=0, b=curve->first; b!=NULL; b=b->next, i++)
		{
		    btri = link_tri_to_bond(NULL,null_tris[ntris-1-i],*s,b,curve);
		    copy_tri_state_to_btri(btri,b,NEGATIVE_ORIENTATION,intfc);
		    copy_tri_state_to_btri(btri,b,POSITIVE_ORIENTATION,intfc);
		}
	    }   //null_side_on_surface.
	}

	dup_nodes = YES;
	while(dup_nodes)
	{
	    dup_nodes = NO;
	    for(n=intfc->nodes; n && *n; n++)
	    {
		for(n1=n+1; n1 && *n1; n1++)
		{
		    if((*n)->posn != (*n1)->posn)
			continue;
		    dup_nodes = YES;

		    //merge nodes *n1 with node *n
		    for(c=(*n1)->in_curves; c && *c; c++)
			change_node_of_curve(*c,NEGATIVE_ORIENTATION,*n);
		    for(c=(*n1)->out_curves; c && *c; c++)
			change_node_of_curve(*c,POSITIVE_ORIENTATION,*n);
		    
		    if(!delete_node(*n1))
		    {
			printf("ERROR install_subdomain_bdry_curves "
		    	       "can not delete node.\n");
			print_node(*n1);
			clean_up(ERROR);
		    }
		    break;
		}
		if(dup_nodes)
		    break;
	    }
	}

/*
	for(c=intfc->curves; c && *c; c++)
	{
	    if(curve_number(*c) != 1)
		continue;
	    printf("#prt st\n");
	    for(b=(*c)->first; b != NULL; b=b->next)
	    {
		p = b->start;
		print_general_vector("b->start", Coords(p), 3, "\n");
		btri = Btris(b)[0];
		slsr(p,Hyper_surf_element(btri->tri),Hyper_surf(btri->surface),
			&sl,&sr);
		printf("#slsr  %d    %d  %d  \n", p, sl, sr);
	    }
	}
*/

	//for (n = intfc->nodes; n && *n; ++n)
	//{
	//    printf("#nd  %d %d\n", *n, (*n)->posn);
	//}

	//#bjet2  two closed curves contact with each other
	//reset_nodes_posn(intfc);

	if (debugging("consistency"))
	{
	    if (!consistent_interface(intfc))
	    {
		screen("ERROR in install_subdomain_bdry_curves(), "
		       "intfc is inconsistent\n");
		clean_up(ERROR);
	    }
	}
	interpolate_intfc_states(intfc) = sav_intrp;
	DEBUG_LEAVE(install_subdomain_bdry_curves)
}		/*end install_subdomain_bdry_curves*/

EXPORT	bool	point_outside_open(
	int		*k,
	float		*nor,
	POINT		*p,
	INTERFACE	*intfc)
{
	int		i;
	RECT_GRID	*gr = computational_grid(intfc);
	float		tol = 1.0e-4;

	zero_scalar(nor, 3*FLOAT);
	for(i=0; i<3; i++)
	{
	    if(rect_boundary_type(intfc,i,0) == OPEN_BOUNDARY && 
	       Coords(p)[i] < gr->VL[i] + gr->h[i])
	    {
		*k = i;
		nor[i] = -1.0;
		nor[3] = (gr->VL[i] - Coords(p)[i])/gr->h[i];
		return YES;
	    }
	    if(rect_boundary_type(intfc,i,1) == OPEN_BOUNDARY && 
	       Coords(p)[i] > gr->VU[i] - gr->h[i])
	    {
		*k = i;
		nor[i] = 1.0;
		nor[3] = (Coords(p)[i] - gr->VU[i])/gr->h[i];
		return YES;
	    }
	}
	return NO;
}	/* end point_outside_open_bdry */



	bool	sep_common_point_from_loop(TRI **, int, TRI**, int*, INTERFACE *);
IMPORT	bool	point_outside_open_bdry(int*, float*, POINT*,INTERFACE*);
IMPORT void sep_common_pt_for_open_bdry(INTERFACE*);
void	set_comm_pt_fac(float);
float	get_comm_pt_fac();

EXPORT void sep_common_pt_for_open_bdry(
	INTERFACE	*intfc)
{
	SURFACE			**s;
	POINT			*p;
	TRI			*tri, *tris[MAX_SUBDOMAIN_TRIS];
	int			i, k, nt;
	float			nor[4], tmp_fac;

	if(!debugging("sep_for_open"))
	    return;

	nt = 0;
	for(s=intfc->surfaces; s && *s; s++)
	{
	    for(tri=first_tri(*s); !at_end_of_tri_list(tri,*s); tri=tri->next)
	    {
		for(i=0; i<3; i++)
		{
		    p = Point_of_tri(tri)[i];
		    if(point_outside_open(&k, nor, p, intfc))
		    {
		        tris[nt++] = tri;
			if(nt >= MAX_SUBDOMAIN_TRIS)
			{
			    printf("ERROR sep_common_pt_for_open_bdry "
				   "too many tris.\n");
			    clean_up(ERROR);
			}
			break;
		    }
		}
	    }
	}

	tmp_fac = get_comm_pt_fac();
	set_comm_pt_fac(0.999);
	if(nt > 0)
	    sep_common_point_from_loop(tris, nt, NULL, NULL, intfc);
	set_comm_pt_fac(tmp_fac);
}

EXPORT void install_subdomain_bdry_curves_org(
	INTERFACE	*intfc)
{
	BOND	 *b;
	BOND_TRI *btri, *bte;
	CURVE	 *curve, **c;
	NODE	 *ns, *ne, **n, **n1;
	POINT	 *p, *ps, *pe;
	TRI	 *tri_start, *tri_end, *start_tri;
	SURFACE	 **s;
	Locstate sl, sr;
	bool  	 sav_intrp, dup_nodes;
	int	 side_start, side_end, start_side;
	int	 dim = intfc->dim;

	DEBUG_ENTER(install_subdomain_bdry_curves)
	sav_intrp = interpolate_intfc_states(intfc);
	interpolate_intfc_states(intfc) = NO;
	
	for (s = intfc->surfaces; s && *s; ++s)
	{
	    while (null_side_on_surface(*s,&start_tri,&start_side))
	    {
		find_ending_null_side(start_tri,start_side,
				&tri_start,&side_start);
		
		ps = Point_of_tri(tri_start)[side_start];
	    	ns = make_node(ps);
		pe = Point_of_tri(tri_start)[Next_m3(side_start)];
		ne = make_node(pe);
		curve = make_curve(NO_COMP,NO_COMP,ns,ne);

		hsbdry_type(curve) = SUBDOMAIN_HSBDRY;
	    	install_curve_in_surface_bdry(*s,curve,POSITIVE_ORIENTATION);
	    	
		//printf("#c %d | %d  %d | %d  %d\n", curve_number(curve), 
		//	ns, ne, ns->posn, ne->posn);

		if(curve_number(curve) == 1)
		    add_to_debug("subdo_cur");

		btri = link_tri_to_bond(NULL,tri_start,*s,curve->first,curve);
		copy_tri_state_to_btri(btri,curve->first,
				POSITIVE_ORIENTATION,intfc);
		copy_tri_state_to_btri(btri,curve->first,
				NEGATIVE_ORIENTATION,intfc);

	    	b = curve->first;
		tri_end = tri_start;
		side_end = side_start;
		
		//following_null_tri uses CLOCKWISE
		//insert_point_in_bond inserts point in the start of the curve
		while((tri_start = find_following_null_tri(tri_start,&p,
					&side_start,CLOCKWISE)) != NULL)
		{
		    //new bond is inserted in b->next, the bond_tri 
		    //of current bond is saved in bte.
		    bte = Bond_tri_on_side(tri_end,side_end);
		    if (insert_point_in_bond(ns->posn,b,curve) !=
			FUNCTION_SUCCEEDED)
		    {
			screen("ERROR in install_subdomain_bdry_curves(), "
		               "insert_point_in_bond() failed\n");
			clean_up(ERROR);
		    }
		    
		    ns->posn = b->start = p;
		    set_bond_length(b,dim);
		    
		    btri = link_tri_to_bond(NULL,tri_end,*s,b->next,curve);
		    copy_tri_state_to_btri(btri,b->next,
		    		NEGATIVE_ORIENTATION,intfc);
		    copy_tri_state_to_btri(btri,b->next,
		    		POSITIVE_ORIENTATION,intfc);
		    
		    if(debugging("subdo_cur"))
		        printf("#sub %d | %d %d   %d %d\n", btri,
			    left_start_btri_state(btri), right_start_btri_state(btri),
			    left_end_btri_state(btri), right_end_btri_state(btri));
		    
		    btri = bte;
		    (void) link_tri_to_bond(btri,tri_start,*s,b,curve);
		    copy_tri_state_to_btri(btri,b,NEGATIVE_ORIENTATION,intfc);
		    copy_tri_state_to_btri(btri,b,POSITIVE_ORIENTATION,intfc);
	
		    if(debugging("subdo_cur"))
		        printf("#btr %d | %d %d   %d %d\n",  btri,
			    left_start_btri_state(btri), right_start_btri_state(btri),
			    left_end_btri_state(btri), right_end_btri_state(btri));

		    if (ns->posn == ne->posn) //Closed loop formed
		    {
			change_node_of_curve(curve,POSITIVE_ORIENTATION,ne);
			if(!delete_node(ns))
			{
			    printf("ERROR install_subdomain_bdry_curves "
			    	   "can not delete ns node for a loop.\n");
			    print_node(ns);
			    clean_up(ERROR);
			}
			break;
		    }
	    
		    tri_end = tri_start;
		    side_end = side_start;
		}
	    }
	}

	dup_nodes = YES;
	while(dup_nodes)
	{
	    dup_nodes = NO;
	    for(n=intfc->nodes; n && *n; n++)
	    {
		for(n1=n+1; n1 && *n1; n1++)
		{
		    if((*n)->posn != (*n1)->posn)
			continue;
		    dup_nodes = YES;

		    //merge nodes *n1 with node *n
		    for(c=(*n1)->in_curves; c && *c; c++)
			change_node_of_curve(*c,NEGATIVE_ORIENTATION,*n);
		    for(c=(*n1)->out_curves; c && *c; c++)
			change_node_of_curve(*c,POSITIVE_ORIENTATION,*n);
		    
		    if(!delete_node(*n1))
		    {
			printf("ERROR install_subdomain_bdry_curves "
		    	       "can not delete node.\n");
			print_node(*n1);
			clean_up(ERROR);
		    }
		    break;
		}
		if(dup_nodes)
		    break;
	    }
	}

	for(c=intfc->curves; c && *c; c++)
	{
	    if(curve_number(*c) != 1)
		continue;
	    printf("#prt st\n");
	    for(b=(*c)->first; b != NULL; b=b->next)
	    {
		p = b->start;
		print_general_vector("b->start", Coords(p), 3, "\n");
		btri = Btris(b)[0];
		slsr(p,Hyper_surf_element(btri->tri),Hyper_surf(btri->surface),
			&sl,&sr);
		printf("#slsr  %d    %d  %d  \n", p, sl, sr);
	    }
	}

	//for (n = intfc->nodes; n && *n; ++n)
	//{
	//    printf("#nd  %d %d\n", *n, (*n)->posn);
	//}

	//#bjet2  two closed curves contact with each other
	//reset_nodes_posn(intfc);

	if (debugging("consistency"))
	{
	    if (!consistent_interface(intfc))
	    {
		screen("ERROR in install_subdomain_bdry_curves(), "
		       "intfc is inconsistent\n");
		clean_up(ERROR);
	    }
	}
	interpolate_intfc_states(intfc) = sav_intrp;
	DEBUG_LEAVE(install_subdomain_bdry_curves)
}		/*end install_subdomain_bdry_curves*/


LOCAL bool null_side_on_surface(
	SURFACE *s,
	TRI     **tri_start,
	int     *side_start)
{
	TRI *tri;
	int i;

	for (tri = first_tri(s); !at_end_of_tri_list(tri,s); tri = tri->next)
	{
	    for (i = 0; i < 3; ++i)
	    {
		if (Tri_on_side(tri,i) == NULL)
		{
		    *side_start = i;
		    *tri_start = tri;
		    return YES;
		}
	    }
	}
	return NO;
}	/* end null_side_on_surface */

LOCAL bool buffer_extension3d1(
	INTERFACE	*intfc,
	INTERFACE	*adj_intfc,
	int		dir,
	int		nb,
	bool		status)
{
	RECT_GRID	*gr = computational_grid(intfc);

	DEBUG_ENTER(buffer_extension3d1)

	set_current_interface(intfc);

		/* Patch tris from adj_intfc to intfc */
	if (!append_adj_intfc_to_buffer1(intfc,adj_intfc,gr,dir,nb))
	{
	       status = FUNCTION_FAILED;
	        (void) printf("WARNING in buffer_extension3d1(), "
	                  "append_adj_intfc_to_buffer1() failed\n");
	        DEBUG_LEAVE(buffer_extension3d1)
	        return status;
	}
	
	DEBUG_LEAVE(buffer_extension3d1)
	return status;
}	/*end buffer_extension3d1*/

LOCAL	void	shift_interface(
	INTERFACE *intfc,
	float     T,
	int       dir)
{
	POINT   *p;
	SURFACE **s;
	TRI     *t;
	int     i;

	DEBUG_ENTER(shift_interface)

	if (DEBUG)
	{
	    char dname[1024];
	    static int ntimes[3];
	    (void) printf("Shifting interface %llu by %g in direction %d\n",
			  interface_number(intfc),T,dir);
	    print_interface(intfc);
	    (void) sprintf(dname,"fscatter/shift_interface/Into%d.%d.%s%g",
			   ntimes[dir],dir,(T>0.0) ? "+" : "",T);
	    ++ntimes[dir];
	    gview_plot_interface(dname,intfc);
	}

		/* Shift points on interface */
	(void) next_point(intfc,NULL,NULL,NULL);/*reset sort status*/
	for (s = intfc->surfaces; s && *s; ++s)
	{
	    for (t = first_tri(*s); !at_end_of_tri_list(t,*s); t = t->next)
	    {
		for (i = 0; i < 3; ++i)
		{
		    p = Point_of_tri(t)[i];
		    if (sorted(p) == NO)
	                Coords(p)[dir] += T;
		    sorted(p) = YES;
		}
	    }
	}

	if (DEBUG)
	{
	    char dname[1024];
	    static int ntimes[3];
	    (void) printf("Interface %llu after shift by %g in direction %d\n",
			  interface_number(intfc),T,dir);
	    print_interface(intfc);
	    (void) sprintf(dname,"fscatter/shift_interface/Outof%d.%d.%s%g",
			   ntimes[dir],dir,(T>0.0)?"+":"",T);
	    ++ntimes[dir];
	    gview_plot_interface(dname,intfc);
	}

	DEBUG_LEAVE(shift_interface)
}		/*end periodic_shift_interface*/


LOCAL 	int append_adj_intfc_to_buffer1(
	INTERFACE	*intfc,		/* my interface 	       */
	INTERFACE	*adj_intfc,	/* received interface	       */
	RECT_GRID	*grid,		/* Rectangular grid for region */
	int		dir,
	int		nb)
{
	INTERFACE	*cur_intfc;
	SURFACE		**s, **as;
	int		p_size;		/*Size of space allocated for p_table*/
	static P_LINK	*p_table = NULL;/* Table of matching points on intfc
					 * and adj_intfc*/
	static int      len_p_table = 0;
	bool      	corr_surf_found;

	DEBUG_ENTER(append_adj_intfc_to_buffer1)

	if (DEBUG)
	{
	    char dname[256];
	    static int ntimes[3][2];
	    static const char *strdir[3] = { "X", "Y", "Z" };
	    static const char *strnb[2] = { "LOWER", "UPPER" };

	    (void) sprintf(dname,"fscatter/"
				 "append_adj_intfc_to_buffer1/Data%d-%s_%s/%s",
			         ntimes[dir][nb],strdir[dir],strnb[nb],
				 "intfc_gv");
	    gview_plot_interface(dname,intfc);
	    (void) sprintf(dname,"fscatter/"
				 "append_adj_intfc_to_buffer1/Data%d-%s_%s/%s",
			         ntimes[dir][nb],strdir[dir],strnb[nb],
				 "adj_intfc_gv");
	    gview_plot_interface(dname,adj_intfc);

	    ++ntimes[dir][nb];
	}

	cur_intfc = current_interface();
	set_current_interface(intfc);

	p_size = 4*(adj_intfc->num_points) + 1;
	if (len_p_table < p_size)
	{
	    len_p_table = p_size;
	    if (p_table != NULL)
		free(p_table);
	    uni_array(&p_table,len_p_table,sizeof(P_LINK));
	}
	
	reset_hash_table(p_table,p_size);
	
	/* Begin patching adj_intfc to current interface */
	for (as = adj_intfc->surfaces; as && *as; ++as)
	{
	    corr_surf_found = NO;
	    if(wave_type(*as) == FIRST_SCALAR_PHYSICS_WAVE_TYPE && debugging("step_out"))
	    {    
		add_to_debug("out_matching");
	        printf("#out_mathcing\n");
	    }
	    for (s = intfc->surfaces; s && *s; ++s)
	    {
		/*
		*  COMMENT -
		*  The Hyper_surf_index() function is not
		*  fully supported.  This will fail in the
		*  presence of interface changes in topology
		*  TODO: FULLY SUPPORT THIS OBJECT
		*/
                
		//#bjet2  assume one neg and pos comp gives ONLY ONE surf
                if(negative_component(*as) == negative_component(*s) &&
                   positive_component(*as) == positive_component(*s))
		//if (Hyper_surf_index(*s) == Hyper_surf_index(*as))
		{
		    corr_surf_found = YES;
		    if (!append_buffer_surface1(*s,*as,grid,dir,nb,p_table,
						   p_size))
		    {
			set_current_interface(cur_intfc);
			
			(void) printf("WARNING in "
			              "append_adj_intfc_to_buffer1(), "
			              "append surface failed\n");
			
			DEBUG_LEAVE(append_adj_intfc_to_buffer1)
			return NO;
		    }
		}
	    }
	    if (!corr_surf_found && as && *as)
	    {
	    	SURFACE *surf;
		if (as==NULL)
		    continue;
		surf = copy_buffer_surface(*as,p_table,p_size);
		Hyper_surf_index(surf) = Hyper_surf_index((*as));
	    }
	}
	
	//printf("\n#merge_curve\n");
	merge_curves(intfc);
	//printf("#merge_curve af\n");
	
	set_current_interface(cur_intfc);
	
	//null_sides_are_consistent();
	//check_print_front("After append_adj_intfc_to_buffer1", "append_adj", 'g', 
	//           intfc, 1, -1, NO);
	
	DEBUG_LEAVE(append_adj_intfc_to_buffer1)
	return YES;
}		/*end append_adj_intfc_to_buffer1*/

LOCAL 	int append_adj_intfc_to_buffer1_old(
	INTERFACE	*intfc,		/* my interface 	       */
	INTERFACE	*adj_intfc,	/* received interface	       */
	RECT_GRID	*grid,		/* Rectangular grid for region */
	int		dir,
	int		nb)
{
	INTERFACE	*cur_intfc;
	SURFACE		**s, **as;
	int		p_size;		/*Size of space allocated for p_table*/
	static P_LINK	*p_table = NULL;/* Table of matching points on intfc
					 * and adj_intfc*/
	static int      len_p_table = 0;
	bool      	corr_surf_found;

	DEBUG_ENTER(append_adj_intfc_to_buffer1)

	if (DEBUG)
	{
	    char dname[256];
	    static int ntimes[3][2];
	    static const char *strdir[3] = { "X", "Y", "Z" };
	    static const char *strnb[2] = { "LOWER", "UPPER" };

	    (void) sprintf(dname,"fscatter/"
				 "append_adj_intfc_to_buffer1/Data%d-%s_%s/%s",
			         ntimes[dir][nb],strdir[dir],strnb[nb],
				 "intfc_gv");
	    gview_plot_interface(dname,intfc);
	    (void) sprintf(dname,"fscatter/"
				 "append_adj_intfc_to_buffer1/Data%d-%s_%s/%s",
			         ntimes[dir][nb],strdir[dir],strnb[nb],
				 "adj_intfc_gv");
	    gview_plot_interface(dname,adj_intfc);

	    ++ntimes[dir][nb];
	}

	cur_intfc = current_interface();
	set_current_interface(intfc);

	p_size = 4*(adj_intfc->num_points) + 1;
	if (len_p_table < p_size)
	{
	    len_p_table = p_size;
	    if (p_table != NULL)
		free(p_table);
	    uni_array(&p_table,len_p_table,sizeof(P_LINK));
	}

	//#bjet2
	reset_hash_table(p_table,p_size);
	
	/* Begin patching adj_intfc to current interface */
	for (s = intfc->surfaces; s && *s; ++s)
	{
	    corr_surf_found = NO;
	    for (as = adj_intfc->surfaces; as && *as; ++as)
	    {
		/*
		*  COMMENT -
		*  The Hyper_surf_index() function is not
		*  fully supported.  This will fail in the
		*  presence of interface changes in topology
		*  TODO: FULLY SUPPORT THIS OBJECT
		*/
		if (Hyper_surf_index(*s) == Hyper_surf_index(*as))
		{
		    corr_surf_found = YES;
		    if (!append_buffer_surface1(*s,*as,grid,dir,nb,p_table,
						   p_size))
		    {
			set_current_interface(cur_intfc);
			
			(void) printf("WARNING in "
			              "append_adj_intfc_to_buffer1(), "
			              "append surface failed\n");
			(void) printf("Surface\n");
			print_surface(*s);
			(void) printf("Adjacent surface\n");
			print_surface(*as);
			(void) printf("intfc\n");
			print_interface(intfc);
			(void) printf("adj_intfc\n");
			print_interface(adj_intfc);
			
			DEBUG_LEAVE(append_adj_intfc_to_buffer1)
			return NO;
		    }
		}
	    }
	    if (!corr_surf_found && as && *as)
	    {
	    	SURFACE *surf;
		if (as==NULL)
		    continue;
		surf = copy_buffer_surface(*as,p_table,p_size);
		Hyper_surf_index(surf) = Hyper_surf_index((*as));
	    }
	}
	set_current_interface(cur_intfc);
	DEBUG_LEAVE(append_adj_intfc_to_buffer1)
	return YES;
}		/*end append_adj_intfc_to_buffer1*/



EXPORT void set_floating_point_tolerance1(
	float		*h)
{
	float eps;
	static const float mfac = 10.0;/*TOLERANCE*/
	static const float gfac = 0.004;/*TOLERANCE*/
	static const float pt_tol = 1.0e-4;
	int   i;

	eps = mfac*MACH_EPS;
	for (i = 0; i < 3; ++i)
	{
	    tol1[i] = gfac*h[i];/*TOLERANCE*/
	    tol_pt[i] = pt_tol*h[i];
	    //tol1[i] = max(tol1[i],eps);
	}
}		/*end set_floating_point_tolerance1*/

int	cut_buffer_tris(SURFACE*, RECT_GRID*, int, int);
void	cut_buffer_tris_from_intfc(INTERFACE*, int, int);
void	make_ref_strip_for_surf(float*, float*, SURFACE*, INTERFACE*);
void	make_ref_strip(float*, float*, INTERFACE*);

#define  cut_case(a)  ((a[0].fg == 0) + (a[1].fg == 0) + (a[2].fg == 0) == 2 ? YES : NO)
// if line cut two sides of the tri, it returns YES.
#define	 out_side(a)  (a[0].fg != 0 ? 0 : (a[1].fg !=0 ? 1 : 2))
// line without intersection with the side.
#define	 cut_side(a)  (cut_case(a) ? Next_m3(out_side(a)) : (a[0].fg == 0 ? 0 : (a[1].fg == 0 ? 1 : 2)))
// line cut the side

typedef  struct {
	int	fg;
	//edge flag  0: side across the line;
	//	    -1: side inside the line;
	//	    -2: side outside the line;
	
	POINT	*pt;
	//corssing point if fg == 0
}	EDGE_CUT;

#define	MAX_EDGE_CUT	3000

int	neighbor_tri_side(TRI*, TRI*);

//nbtri is on which side of tri
int	neighbor_tri_side(
	TRI	*tri, 
	TRI	*nbtri)
{
	int	i;

	for(i=0; i<3; i++)
	    if(!is_side_bdry(tri,i) && Tri_on_side(tri,i) == nbtri)
		return i;
	return -1;
}

int	cut_split_tris(
	TRI		**new_tris,
	TRI		*tri,
	SURFACE		*s,
	EDGE_CUT	**edge_cut)
{
	EDGE_CUT	*A;
	int		i, j, k, side, nside, pside;
	int		nnb, nt, nnt, nnt1;
	POINT		**p, *pa, *pb, *pte[2];
	TRI		*new_tri1, *new_tri2, *nbtri;
	TRI		*nbtris[2], *new_nbtris[3], **ptris;

	DEBUG_ENTER(cut_split_tris)

	//tri is inside or outside, return.
	if(Tri_order(tri) < 0)
	{
	    DEBUG_LEAVE(cut_split_tris)
	    return 0;
	}

	A = edge_cut[Tri_order(tri)];
	
	nnb = 0;
	if(cut_case(A))
	{
	    p = Point_of_tri(tri);
	    
	    side = out_side(A);
	    pside = Prev_m3(side);
	    nside = Next_m3(side);

	    pa = A[nside].pt;
	    pb = A[pside].pt;
	    
	    //fact: pside and nside has cut point on them. if a neighbor tri is on
	    //the side Tri_order must have a value
	    nbtris[0] = Tri_on_side(tri,pside);
	    pte[0] = pb;
	    if(nbtris[0] != NULL)
		nnb++;
	    
	    nbtris[nnb] = Tri_on_side(tri,nside);
	    pte[nnb] = pa;
	    if(nbtris[nnb] != NULL)
		nnb++;
	    
	    //disconnect the neighbor tris
	    for(i=0; i<nnb; i++)
	        Tri_on_side(nbtris[i], neighbor_tri_side(nbtris[i],tri)) = NULL;
	    Tri_on_side(tri,pside) = NULL;
	    Tri_on_side(tri,nside) = NULL;
    
	    new_tri1 = make_tri(p[nside],pa,pb, NULL, NULL, NULL, NO);
	    new_tri2 = make_tri(pa,p[pside],pb, NULL, NULL, NULL, NO);
	    insert_tri_at_tail_of_list(new_tri1,s);
	    insert_tri_at_tail_of_list(new_tri2,s);
	    p[pside] = pb;
	    
	    link_neighbor_null_side_tris(new_tri1, new_tri2);
	    link_neighbor_null_side_tris(new_tri1, tri);
	    
	    //out side is inside the line
	    if(A[side].fg == -1)
	    {
		Tri_order(tri) = -1;
		Tri_order(new_tri1) = -1;
		Tri_order(new_tri2) = -2;
	    }
	    else
	    {
		Tri_order(tri) = -2;
		Tri_order(new_tri1) = -2;
		Tri_order(new_tri2) = -1;
	    }

	    new_tris[0] = tri;
	    new_tris[1] = new_tri1;
	    new_tris[2] = new_tri2;
	    nt = 3;
	}
	else
	{
	    p = Point_of_tri(tri);
	    
	    side = cut_side(A);
	    pside = Prev_m3(side);
	    nside = Next_m3(side);

	    pa = A[side].pt;
	    
	    nbtris[0] = Tri_on_side(tri,side);
	    pte[0] = pa;
	    if(nbtris[0] != NULL)
		nnb++;
    
	    //disconnect the neighbor tris
	    for(i=0; i<nnb; i++)
	        Tri_on_side(nbtris[i], neighbor_tri_side(nbtris[i],tri)) = NULL;
	    
	    new_tri1 = make_tri(p[pside], pa, p[nside], NULL,NULL,NULL,NO);
	    insert_tri_at_tail_of_list(new_tri1,s);
	   
	    //reconnect nside neighbor
	    Neighbor_on_side(new_tri1,2) = Neighbor_on_side(tri,nside);
	    if(is_side_bdry(tri,nside))
	    {
		set_20_bdry(Boundary_tri(new_tri1), YES);
		set_side_bdry(Boundary_tri(tri), nside, NO);
	    }
	    if(Neighbor_on_side(tri,nside) != NULL)
		if(is_side_bdry(tri,nside))
		    Bond_tri_on_side(tri,nside)->tri = new_tri1;
	        else
		{
		    nbtri = Tri_on_side(tri,nside);
		    i = neighbor_tri_side(nbtri,tri);
		    Tri_on_side(nbtri,i) = new_tri1;
		}
	    
	    p[nside] = pa;
	    Tri_on_side(tri,side) = NULL;
	    Tri_on_side(tri,nside) = NULL;
	    
	    link_neighbor_null_side_tris(new_tri1, tri);
	    
	    if(A[pside].fg == -1)
	    {
		Tri_order(tri) = -1;
		Tri_order(new_tri1) = -2;
	    }
	    else
	    {
		Tri_order(tri) = -2;
		Tri_order(new_tri1) = -1;
	    }

	    new_tris[0] = tri;
	    new_tris[1] = new_tri1;
	    nt = 2;
	}

	//split the neighbor tris and linking them.
	for(i=0; i<nnb; i++)
	{
	    nnt = cut_split_tris(new_nbtris, nbtris[i], s, edge_cut);
	    if(nnt == 0)
	    {
		printf("#cut_split_tris, enter nnt == 0 case.\n");

		//check if pte[i] is a vertex of nbtri
		for(j=0; j<3; j++)
		    if(Point_of_tri(nbtris[i])[j] == pte[i])
		    {
			nbtri = nbtris[i];
			break;
		    }
		
		//find nbtri which has pte[i] as its vertex.
		if(j == 3)
		{
		    for(j=0; j<3; j++)
		    {
			if(is_side_bdry(nbtris[i], j))
			    continue;
			nbtri = Tri_on_side(nbtris[i],j);
			if(nbtri == NULL)
			    continue;
			for(k=0; k<3; k++)
			    if(Point_of_tri(nbtri)[k] == pte[i])
				break;
			if(k < 3)
			    break;
		    }
		    if(j == 3)
		    {
			printf("ERROR cut_split_tris, unable to split nbtris[%d].\n", i);
			clean_up(ERROR);
		    }
		}

		//nbtri has vertex pte[i]
		nnt1 = set_tri_list_around_point(pte[i], 
		    nbtri, &ptris, s->interface);
		for(j=0; j<nnt1; j++)
		    new_nbtris[j] = ptris[j];
		nnt = nnt1;
		
		printf("#new_nbtris %d\n", pte[i]);
		for(j=0; j<nnt; j++)
		    print_tri(new_nbtris[j], s->interface);
	
		printf("#new_tris\n");
		for(j=0; j<nt; j++)
		    print_tri(new_tris[j], s->interface);
		
		//printf("ERROR cut_split_tris, unable to split nbtris[%d].\n", i);
		//clean_up(ERROR);
	    }

	    for(j=0; j<nnt; j++)
		for(k=0; k<nt; k++)
		    link_neighbor_null_side_tris(new_tris[k], new_nbtris[j]);
	}

	DEBUG_LEAVE(cut_split_tris)
	
	return nt;
}


void	flag_point_pos(
	float		plane,
	int		dir,
	int		nb,
	SURFACE		*s,
	INTERFACE	*intfc)
{
	RECT_GRID	*gr = computational_grid(intfc);
	POINT		**p;
	TRI		*tri;
	float		crds, tol;
	int		i;

	tol = 0.01*min3(gr->h[0], gr->h[1], gr->h[2]);

	//1 not calculated
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    for(i=0; i<3; i++)
		Point_order(Point_of_tri(tri)[i]) = 1;

	//check points 0 on line -1 insdie line  -2 outside line
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    for(i=0; i<3; i++)
	    {
		p = Point_of_tri(tri);
		if(Point_order(p[i]) != 1)
		    continue;
		
		crds = Coords(p[i])[dir];
		if(crds > plane + tol)
		    Point_order(p[i]) = nb == 0 ? -1 : -2;
		else if(crds < plane - tol)
		    Point_order(p[i]) = nb == 0 ? -2 : -1 ;
		else
		    Point_order(p[i]) = 0;
	    }
}

void	cut_curve_along_line(
	int		dir,
	int		nb,
	float		plane,
	INTERFACE	*intfc)
{
	RECT_GRID	*gr = computational_grid(intfc);
	CURVE	**c;
	BOND	*bd;
	POINT	*p, *p1, *p2, *newp;
	float	crds, a, b, tol;

	tol = 0.01*min3(gr->h[0], gr->h[1], gr->h[2]);
	
	for (c = intfc->curves; c && *c; ++c)
	{
	    for (bd = (*c)->first; bd != NULL; bd = bd->next)
	    {
		p = bd->start;
		crds = Coords(p)[dir];
		if(crds > plane + tol)
		    Point_order(p) = nb == 0 ? -1 : -2;
		else if(crds < plane - tol)
		    Point_order(p) = nb == 0 ? -2 : -1 ;
		else
		    Point_order(p) = 0;
	
		p = bd->end;
		crds = Coords(p)[dir];
		if(crds > plane + tol)
		    Point_order(p) = nb == 0 ? -1 : -2;
		else if(crds < plane - tol)
		    Point_order(p) = nb == 0 ? -2 : -1 ;
		else
		    Point_order(p) = 0;
	    }
cut_curve:
	    for (bd = (*c)->first; bd != NULL; bd = bd->next)
	    {
		p1 = bd->start;
		p2 = bd->end;
		if(Point_order(p1) == Point_order(p2))
		    continue;
		if(Point_order(p1) == 0 || Point_order(p2) == 0)
		    continue;
		
		a = fabs(Coords(p1)[dir]-plane);
		b = fabs(Coords(p2)[dir]-plane);
		newp = copy_point(p1);

		Coords(newp)[dir] = plane;
		Coords(newp)[Next_m3(dir)] = 
		    b*Coords(p1)[Next_m3(dir)] + a*Coords(p2)[Next_m3(dir)];
		Coords(newp)[Next_m3(dir)] /= (a+b);
		    
		Coords(newp)[Prev_m3(dir)] = 
		    b*Coords(p1)[Prev_m3(dir)] + a*Coords(p2)[Prev_m3(dir)];
		Coords(newp)[Prev_m3(dir)] /= (a+b);
		Point_order(newp) = 0;
	
		insert_point_in_bond(newp, bd, *c);
		goto cut_curve;
	    }
	}
}

void	flag_null_on_line_tris(
	float		plane,
	int		dir,
	int		nb,
	SURFACE		*s,
	INTERFACE	*intfc)
{
	int	i;
	TRI	*tri;
	POINT	**p;

	flag_point_pos(plane, dir, nb, s, intfc);
	
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    Tri_order(tri) = 0;
	
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    for(i=0; i<3; i++)
	    {
		p = Point_of_tri(tri);
		if(Point_order(p[i]) == 0 && Point_order(p[Next_m3(i)]) == 0)
		{
		    if(Tri_on_side(tri, i) != NULL)
		    {
			continue;
			printf("ERROR flag_null_on_line_tris, bdry tri side is not null.\n");
			printf("side %d\n", i);
			print_tri(tri, intfc);
			clean_up(ERROR);
		    }
		    Tri_order(tri) |= Bin_side(i);
		    break;
		}
	    }
}


void	set_surf_edge_cut(
	EDGE_CUT	**edge_cut,
	float		plane,
	int		dir,
	int		nb,
	SURFACE		*s,
	INTERFACE	*intfc)
{
	int	i, j, k, nt, pf[3];
	float	a, b;
	POINT	**p, *newp;
	TRI	*tri, *nbtri;

	flag_point_pos(plane, dir, nb, s, intfc);

	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    Tri_order(tri) = -3;

	nt = 0;
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	{
	    p = Point_of_tri(tri);
	    for(i=0; i<3; i++)
		pf[i] = Point_order(p[i]);

	    //no inside point, remove tri
	    if(pf[0] != -1 && pf[1] != -1 && pf[2] != -1)
	    {
		Tri_order(tri) = -2;
		continue;
	    }
	    
	    //no outside point, keep tri
	    if(pf[0] != -2 && pf[1] != -2 && pf[2] != -2)
	    {
		Tri_order(tri) = -1;
		continue;
	    }

	    //there are edge cuts and at least 1 inside 1 outside
	    Tri_order(tri) = nt;
	    for(i=0; i<3; i++)
	    {
		j = Next_m3(i);
		if(pf[i] == pf[j])  //edge inside or outside
		    edge_cut[nt][i].fg = pf[i];
		else  if(pf[i] == 0)  //1 point on
		    edge_cut[nt][i].fg = pf[j];
		else  if(pf[j] == 0)  //1 point on
		    edge_cut[nt][i].fg = pf[i];
		else //1 in and 1 out
		{
		    edge_cut[nt][i].fg = 0;
		   
		    //check if edge crx is calculated by the neighbor tri
		    nbtri = Tri_on_side(tri, i);
		    if(nbtri != NULL && Tri_order(nbtri) >= 0)
		    {
			k = Tri_order(nbtri);
			edge_cut[nt][i].pt = 
			    edge_cut[k][neighbor_tri_side(nbtri,tri)].pt;
		    }
		    else
		    {
			a = fabs(Coords(p[i])[dir]-plane);
			b = fabs(Coords(p[j])[dir]-plane);
			newp = copy_point(p[i]);

			Coords(newp)[dir] = plane;
			Coords(newp)[Next_m3(dir)] = 
			    b*Coords(p[i])[Next_m3(dir)] + a*Coords(p[j])[Next_m3(dir)];
			Coords(newp)[Next_m3(dir)] /= (a+b);
		    
			Coords(newp)[Prev_m3(dir)] = 
			    b*Coords(p[i])[Prev_m3(dir)] + a*Coords(p[j])[Prev_m3(dir)];
			Coords(newp)[Prev_m3(dir)] /= (a+b);
		   
			interpolate_crx_pt_states_on_edge(intfc,newp,tri,s,i);
			
			edge_cut[nt][i].pt = newp; 
		    }
		}
	    }

	    //crx tri is found
	    nt++;
	    if(nt >= MAX_EDGE_CUT)
	    {
		printf("ERROR in set_surf_edge_cut, too many cut edges.\n");
		clean_up(ERROR);
	    }
	}
}

void	cut_surf_along_line(
	SURFACE		*s,
	EDGE_CUT	**edge_cut)
{
	TRI	*tri, *tris[MAX_EDGE_CUT], *new_tris[3];
	int	i, nt;

	nt = 0;
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    if(Tri_order(tri) >= 0)
		tris[nt++] = tri;
	
	for(i=0; i<nt; i++)
	    cut_split_tris(new_tris, tris[i], s, edge_cut);
	
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    if(Tri_order(tri) == -2)
		remove_tri_from_surface(tri,s,NO);
	
}
		
void	cut_intfc_along_bdry(int, int, INTERFACE*);

void	cut_intfc_along_bdry(
	int		dir,
	int		nb,
	INTERFACE	*intfc)
{
	static EDGE_CUT	**edge_cut = NULL;
	float		plane, tol;
	RECT_GRID	*gr = computational_grid(intfc);
	SURFACE		**s;
	INTERFACE	*sav_intfc = current_interface();

	DEBUG_ENTER(cut_intfc_along_bdry)
	
	set_current_interface(intfc);

	if(edge_cut == NULL)
	    bi_array(&edge_cut, MAX_EDGE_CUT,3,sizeof(EDGE_CUT));

	if(nb == 0)
	    plane = gr->L[dir] + 0.5*gr->h[dir];
	else
	    plane = gr->U[dir] - 0.5*gr->h[dir];
       
	cut_curve_along_line(dir, nb, plane, intfc);
	
	for(s = intfc->surfaces; s && *s; ++s)
	{
	    set_surf_edge_cut(edge_cut,plane,dir,nb,*s,intfc);
	    cut_surf_along_line(*s, edge_cut);
	}
	
	{
	CURVE	**c;
	BOND	*bs;
	BOND_TRI	**btris;

	for (c = intfc->curves; c && *c; ++c)
	{
	    //printf("#cut_intfc c = %d\n", *c);
	    for (bs = (*c)->first; bs != NULL; bs = bs->next)
	    {
		btris = Btris(bs);
	        //printf("btris %d  %d  | ", bs, btris);
		if(btris != NULL && *btris == NULL)
		{
		    printf(" #  ");
		    Btris(bs) = NULL;
		}
		//for(btris = Btris(bs); btris && *btris; btris++)
		    //printf(" %d ", *btris);
		//printf("\n");
	    }
	}
	}

	cut_out_curves_in_buffer(intfc);
	
	set_current_interface(sav_intfc);

	DEBUG_LEAVE(cut_intfc_along_bdry)
}

void	flag_buffer_tris(int, int, INTERFACE*);
void	flag_buffer_tris(
	int		dir,
	int		nb,
	INTERFACE	*intfc)
{
	float		plane;
	RECT_GRID	*gr = computational_grid(intfc);
	SURFACE		**s;

	if(nb == 0)
	    plane = gr->L[dir] + 0.5*gr->h[dir];
	else
	    plane = gr->U[dir] - 0.5*gr->h[dir];
        
	for(s = intfc->surfaces; s && *s; ++s)
	    flag_null_on_line_tris(plane, dir, nb, *s, intfc);
	
	DEBUG_LEAVE(cut_intfc_along_bdry)
}

void	make_ref_strip(
	float		*pt,
	float		*nor,
	INTERFACE	*intfc)
{
	SURFACE		**s;
 	int		i;
	POINT		*p;
	TRI		*tri;
	INTERFACE	*sav_intfc;

	sav_intfc = current_interface();
	set_current_interface(intfc);

	for (s = intfc->surfaces; s && *s; ++s)
	    for(tri=first_tri(*s); !at_end_of_tri_list(tri,*s); tri=tri->next)
	        for(i=0; i<3; i++)
	        {
		    p = Point_of_tri(tri)[i];
		    Cor_point(p) = NULL;
	        }
      
	for (s = intfc->surfaces; s && *s; ++s)
	    make_ref_strip_for_surf(pt, nor, *s, intfc);

	//do not know the order of btris constructed in the above function
	//is consistent with the previous ones, must order interface. 
	order_interface(intfc);
	set_current_interface(sav_intfc);
}

#define	 swap_pointers(a, b)   {st = a; a = b; b = st;}
//assume the curve c is already reflected.

void	reflect_btris_on_curve(
	CURVE		*c,
	INTERFACE	*intfc,
	float		*p,
	float		*nor)
{
	BOND_TRI	**btris;
	BOND		*b;
	Locstate	st;

	//reflect btri states 
	for(b=c->first; b != NULL; b=b->next)
	{
	    for(btris=Btris(b); btris && *btris; btris++)
	    {
		//after reverse curve, b->start is the end of btri.
		reflect_state(left_end_btri_state(*btris), intfc,
			Coords(b->start), p, nor);
		reflect_state(right_end_btri_state(*btris), intfc,
			Coords(b->start), p, nor);

		//printf("%d  %d  | ", left_end_btri_state(*btris), right_end_btri_state(*btris));

		//the last point on curve
		if(!is_closed_curve(c) && b->next == NULL)
		{
		    reflect_state(left_start_btri_state(*btris), intfc,
			    Coords(b->end), p, nor);
		    reflect_state(right_start_btri_state(*btris), intfc,
			    Coords(b->end), p, nor);
		}
		
		swap_pointers(left_start_btri_state(*btris), left_end_btri_state(*btris));
		swap_pointers(right_start_btri_state(*btris), right_end_btri_state(*btris));
	    }
	    //printf("\n");
	}

	//relink btri considering the orientation of c.
	//surface, c and b are reflected
	for(b=c->first; b != NULL; b=b->next)
	{
	    for(btris=Btris(b); btris && *btris; btris++)
	    {
		link_tri_to_bond(*btris, (*btris)->tri, (*btris)->surface, b, c);
	    }
	}

}

void	reflect_curves_on_intfc(INTERFACE*,float*,float*);

void	reflect_curves_on_intfc(
	INTERFACE	*intfc,
	float		*p,
	float		*nor)
{
	CURVE		**c;
	
	for(c=intfc->curves; c && *c; c++)
	{
	    reverse_curve(*c);
	    reflect_btris_on_curve(*c, intfc, p, nor);
	}
}

BOND	*reflect_curve_bond(
	CURVE		**ref_cur,
	POINT		*p,
	POINT		*pf,
	INTERFACE	*intfc)
{
	BOND		*bnew, *b;
	CURVE		**c, *curve;
	int		dir;

	b = NULL;
	for(c=intfc->curves; c && *c; c++)	
	{
	    if((*c)->first->start == p)
	    {
		b = (*c)->first;
		dir = NEGATIVE_ORIENTATION;
		curve = *c;
		break;
	    }
	    if((*c)->last->end == p)
	    {
		b = (*c)->last;
		dir = POSITIVE_ORIENTATION;
		curve = *c;
		break;
	    }
	}
	if(b == NULL)
	{
	    printf("ERROR reflect_curve_bond, no curve has point.\n");
	    clean_up(ERROR);
	}

	//printf("#p = %d  %d   %d %d\n", p, pf, curve, dir);
	//print_curve(curve);

	Boundary_point(pf) = YES;
	if(dir == POSITIVE_ORIENTATION)
	{
	    bnew = Bond(p, pf);
	    bnew->prev = b;
	    curve->last = bnew;
	    bnew->next = NULL;
	    b->next = bnew;
	    ++curve->num_points;
	    curve->end->posn = pf;
	}
	else
	{
	    //print_general_vector("p", Coords(p), 3, "\n");
	    //print_general_vector("pf", Coords(pf), 3, "\n");
 
	    bnew = Bond(pf, p);
	    bnew->next = b;
	    curve->first = bnew;
	    bnew->prev = NULL;
	    b->prev = bnew;
	    ++curve->num_points;
	    curve->start->posn = pf;
	}

	//printf("#after curve\n");
	//print_curve(curve);
	
	*ref_cur = curve;
	return bnew;
}

void	contruct_ref_btri(
	TRI		*tri,
	SURFACE		*s,
	POINT		*p1,
	POINT		*p2,
	float		*pt,
	float		*nor,
	INTERFACE	*intfc)
{
	BOND_TRI	*btri;
	int		sizest;
	CURVE		**c, *curve;
	BOND		*b;

	for(c=intfc->curves; c && *c; c++)
	{
	    //find the corresponding bond.
	    for(b=(*c)->first; b != NULL; b=b->next)
	    {
		if((b->start == p1 && b->end == p2) ||
		   (b->start == p2 && b->end == p1))
		    break;
	    }
	    if(b != NULL)
	    {
		curve = *c;
		break;
	    }
	}
	if(b == NULL)
	{
	    printf("ERROR contruct_ref_btri, the bond is not found.\n");
	    clean_up(ERROR);
	}

	sizest = size_of_state(intfc);
	btri = link_tri_to_bond(NULL, tri, s, b, curve);

	//printf("#btri %d %d | %d %d %d\n", c, btri, b, curve->first, curve->last);
	if(b == curve->first)
	{
	    //printf("#states %d %d\n", left_end_btri_state(btri), right_end_btri_state(btri));
	    ft_assign(left_start_btri_state(btri), left_end_btri_state(btri), sizest);
	    ft_assign(right_start_btri_state(btri), right_end_btri_state(btri), sizest);
	    reflect_state(left_start_btri_state(btri), intfc, Coords(b->start), pt, nor);
	    reflect_state(right_start_btri_state(btri), intfc, Coords(b->start), pt, nor);
	}
	else
	{
	    //printf("#states1 %d %d\n", left_start_btri_state(btri), right_start_btri_state(btri));
	    ft_assign(left_end_btri_state(btri), left_start_btri_state(btri), sizest);
	    ft_assign(right_end_btri_state(btri), right_start_btri_state(btri), sizest);
	    reflect_state(left_end_btri_state(btri), intfc, Coords(b->end), pt, nor);
	    reflect_state(right_end_btri_state(btri), intfc, Coords(b->end), pt, nor);
	}
	//printf("contruct finish.\n");
}

void	make_ref_strip_for_surf(
	float		*pt,
	float		*nor,
	SURFACE		*s,
	INTERFACE	*intfc)
{
	TRI	*tri, **ptris, *new_tri1, *new_tri2;
	int	i,j, nt;
	POINT	*p, *p1, *p2, *p1f, *p2f;
 	BOND	*b1, *b2;
	CURVE	*c1, *c2;

	/*
	for (tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	{
	    for(j=0; j<3; j++)
		if(!is_side_bdry(tri,j) && 
		    (Tri_order(tri) & Bin_side(j)) != 0 )
		    printf("#tria %d  %d  %d\n", Tri_on_side(tri,j), tri, j);
	}
	*/

	//printf("\n#s = %d\n", s);
	//set curve ref point
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    for(i=0; i<3; i++)
	    {
		if((Tri_order(tri) & Bin_side(i)) == 0)
		    continue;
	
		//printf("#tri %d %d\n", tri, i);	
		p1 = Point_of_tri(tri)[i];
		if(Cor_point(p1) == NULL)
		{
		    p1f = copy_point(p1);
		    reflect_point(p1f, pt, nor, intfc);

		    //if a point on curve is reflected, a bond will be made.
		    if(Boundary_point(p1))
			b1 = reflect_curve_bond(&c1, p1, p1f, intfc);
		    Cor_point(p1) = p1f;
		}
		else
		    p1f = (POINT*)Cor_point(p1);

		p2 = Point_of_tri(tri)[Next_m3(i)];
		if(Cor_point(p2) == NULL)
		{
		    p2f = copy_point(p2);
		    reflect_point(p2f, pt, nor, intfc);
		    if(Boundary_point(p2))
			b2 = reflect_curve_bond(&c2, p2, p2f, intfc);
		    Cor_point(p2) = p2f;
		}
		else
		    p2f = (POINT*)Cor_point(p2);

		//printf("1  %d\n", Tri_order(tri));
		//print_tri(tri, intfc);
		new_tri1 = make_tri(p2,p1,p2f,NULL,NULL,NULL,NO);
		insert_tri_at_tail_of_list(new_tri1,s);
		link_neighbor_null_side_tris(new_tri1,tri);

		//printf("2\n");
		new_tri2 = make_tri(p2f,p1,p1f,NULL,NULL,NULL,NO);
		insert_tri_at_tail_of_list(new_tri2,s);
		link_neighbor_null_side_tris(new_tri1,new_tri2);

		//printf("3\n");
		nt = set_tri_list_around_point(p1, tri, &ptris, intfc);
		link_neighbor_null_side_tris(ptris[nt-1], new_tri2);
		
		//print_tri(ptris[nt-1], intfc);
		if(Boundary_point(p2))
		    contruct_ref_btri(new_tri1, s, p2, p2f, pt, nor, intfc);
		
		//printf("4 %d %d\n", new_tri1, new_tri2);
		//print_tri(tri, intfc);
		nt = set_tri_list_around_point(p2, tri, &ptris, intfc);
		link_neighbor_null_side_tris(ptris[0], new_tri1);
		
		//printf("#link1 %d\n", Boundary_point(p1));
		if(Boundary_point(p1))
		    contruct_ref_btri(new_tri2, s, p1, p1f, pt, nor, intfc);
	
		//print_tri(ptris[0], intfc);
	    }

}

void   clip_intfc_in_dir(INTERFACE*, int, int);

void   clip_intfc_in_dir(
	INTERFACE	*intfc,
	int		dir,
	int		nb)
{
	INTERFACE	*cur_intfc = current_interface();
	RECT_GRID	*gr = computational_grid(intfc);
	int		dim = intfc->dim;
	float		L[MAXD],U[MAXD];

	DEBUG_ENTER(clip_intfc_in_dir)
	
	set_current_interface(intfc);
	
	L[dir] = gr->L[dir];
	U[dir] = gr->U[dir];
	if (gr->lbuf[dir] == 0) L[dir] -= 0.5*gr->h[dir];
	if (gr->ubuf[dir] == 0) U[dir] += 0.5*gr->h[dir];
	    
	if(rect_boundary_type(intfc,dir,0) == OPEN_BOUNDARY)
	{
	    L[dir] = gr->VL[dir];
            if(debugging("ref_scat"))
		L[dir] -= 4.0*gr->h[dir];
	}
	if(rect_boundary_type(intfc,dir,1) == OPEN_BOUNDARY)
	{
	    U[dir] = gr->VU[dir];
	    if(debugging("ref_scat"))
		U[dir] += 4.0*gr->h[dir];
	}
	
	open_null_sides1(intfc,L,U,dir,nb);
	
	reset_intfc_num_points(intfc);
	set_current_interface(cur_intfc);
	
	DEBUG_LEAVE(clip_intfc_in_dir)
}



typedef  struct {
	TRI		*tri;
	int		side;
	float		len;
}    TRI_REF;

int compare_tri_ref(const void *a, const void *b)
{
	TRI_REF  *c1=(TRI_REF*)a, *c2=(TRI_REF*)b;

	if(c1->len > c2->len)
	    return -1;
	else
	    return 1;
}
#define		MAX_TRI_REF	1000

void	extend_long_ref_side_for_surf(float*,float*,int, SURFACE*,INTERFACE*,Front*);
void	extend_long_ref_side(float*,float*,int, INTERFACE*,Front*);

void	extend_long_ref_side(
	float		*pt,
	float		*nor,
	int		dir,
	INTERFACE	*intfc, 
	Front		*fr)
{
	SURFACE		**s;
        
	for (s = intfc->surfaces; s && *s; ++s)
	    extend_long_ref_side_for_surf(pt, nor, dir, *s, intfc, fr);
}

void	extend_long_ref_side_for_surf(
	float		*pt,
	float		*nor,
	int		dir,
	SURFACE		*s,
	INTERFACE	*intfc, 
	Front		*fr)
{
	TRI		*tri, **ptris, *new_tri1, *new_tri2;
	int		i,j, nt, nt1, side;
	POINT		*p, *p1, *pf;
	RECT_GRID	*gr = computational_grid(intfc);
	float		tol, len, v[3], hmin;
	TRI_REF		tri_ref[MAX_TRI_REF];
	static Locstate	ans = NULL;

	if(ans == NULL)
	    scalar(&ans, fr->sizest);
	
	hmin = min3(gr->h[0], gr->h[1], gr->h[2]);
	tol = 0.7;

	//set curve ref point
	nt = 0;
	for(tri=first_tri(s); !at_end_of_tri_list(tri,s); tri=tri->next)
	    for(i=0; i<3; i++)
	    {
		if((Tri_order(tri) & Bin_side(i)) == 0)
		    continue;
		
		p1 = Point_of_tri(tri)[i];
		difference(Coords(p1), pt, v, 3);
		len = fabs(Dot3d(v, nor));
		if(len < tol*hmin)
		    continue;

		tri_ref[nt].tri = tri;
		tri_ref[nt].side = i;
		tri_ref[nt].len = len;
		nt++;
		if(nt >= MAX_TRI_REF)
		{
		    printf("ERROR in extend_long_ref_side, nt is too large.\n");
		    clean_up(ERROR);
		}
	    }

	if(nt == 0)
	    return;

	qsort((POINTER)tri_ref, nt, sizeof(TRI_REF), compare_tri_ref);

	printf("#ref_extend %d\n", nt);
	for(i=0; i<nt; i++)
	{
	    tri = tri_ref[i].tri;
	    side = tri_ref[i].side;

	    if((Tri_order(tri) & Bin_side(side)) == 0)
		continue;
	    
	    p = Point_of_tri(tri)[side];
	    pf = copy_point(p);
	    reflect_point(pf, pt, nor, intfc);
	    
	    Coords(pf)[dir] = Coords(pf)[dir]/3.0 + Coords(p)[dir]*2.0/3.0;
	    
	    bi_interpolate_intfc_states(intfc, 1.0/3.0, 2.0/3.0, 
		Coords(pf), left_state(pf), Coords(p), left_state(p), ans);
	    ft_assign(left_state(pf), ans, fr->sizest);
	    
	    bi_interpolate_intfc_states(intfc, 1.0/3.0, 2.0/3.0, 
		Coords(pf), right_state(pf), Coords(p), right_state(p), ans);
	    ft_assign(right_state(pf), ans, fr->sizest);

	    p1 = Point_of_tri(tri)[Next_m3(side)];
	    new_tri1 = make_tri(p1, p ,pf, NULL,NULL,NULL,NO);
	    insert_tri_at_tail_of_list(new_tri1,s);

	    printf("#i = %d\n", i);
	    //print_tri(tri, intfc);
	    //print_tri(new_tri1, intfc);

	    link_neighbor_null_side_tris(new_tri1,tri);
            
	    j = Vertex_of_point(new_tri1,pf);
	    Tri_order(new_tri1) = Bin_side(j);
	    
	    nt1 = set_tri_list_around_point(p, tri, &ptris, intfc);
	    j = Vertex_of_point(ptris[nt1-1], p);
	    
	    p1 = Point_of_tri(ptris[nt1-1])[Prev_m3(j)];
	    new_tri2 = make_tri(p, p1, pf, NULL,NULL,NULL,NO);
	    insert_tri_at_tail_of_list(new_tri2,s);
	    
	    //print_tri(ptris[nt1-1], intfc);
	    //print_tri(new_tri2, intfc);

	    link_neighbor_null_side_tris(new_tri2,ptris[nt1-1]);
	    link_neighbor_null_side_tris(new_tri1,new_tri2);
	    
	    j = Vertex_of_point(new_tri2,p1);
	    Tri_order(new_tri2) = Bin_side(j);

	    set_side_bdry(Tri_order(tri), side, 0);
	    set_side_bdry(Tri_order(ptris[nt1-1]), Vertex_of_point(ptris[nt1-1],p1), 0);
	}
}

void sep_common_pt_for_ref_bdry(
	INTERFACE	*intfc,
	int		dir,
	int		nb)
{
	SURFACE			**s;
	TRI			*tri, *tris[MAX_SUBDOMAIN_TRIS];
	POINT			**p, **p1;
	int			i, j, nt, num;
	float			tmp_fac, cut_plane, crds;
	float			tol = tol1[dir];
	
	cut_plane = nb==0 ? -HUGE_VAL : HUGE_VAL;

	nt = 0;
	for(s=intfc->surfaces; s && *s; s++)
	{
	    for(tri=first_tri(*s); !at_end_of_tri_list(tri,*s); tri=tri->next)
	    {
		if(Tri_order(tri) != 0)
		{
		    tris[nt++] = tri;
		    if(nt >= MAX_SUBDOMAIN_TRIS)
		    {
			printf("ERROR sep_common_pt_for_ref_bdry, too many tris.\n ");
			clean_up(ERROR);
		    }

		    //tri is the triangle needed to connect with the strip
		    //cut_plane is the highest/lowest coord
		    p = Point_of_tri(tri);
		    for(i=0; i<3; i++)
		    {
			crds = Coords(p[i])[dir];
			if((nb == 0 && cut_plane < crds) ||
			   (nb == 1 && cut_plane > crds) )
			    cut_plane = crds;
		    }
		}
	    }
	}

	num = nt;
	for(s=intfc->surfaces; s && *s; s++)
	{
	    for(tri=first_tri(*s); !at_end_of_tri_list(tri,*s); tri=tri->next)
	    {
		if(Tri_order(tri) != 0)
		    continue;
		p = Point_of_tri(tri);
		for(i=0; i<3; i++)
		{
		    crds = Coords(p[i])[dir];
		    if((nb == 0 && cut_plane + tol >= crds) ||
		       (nb == 1 && cut_plane - tol <= crds) )
			break;
		}

		//tri is in the range of ref tris
		if(i < 3)
		{
		    for(i=0; i<3; i++)
		    {
			p = Point_of_tri(tri);
			for(j=0; j<num; j++)
			{
			    p1 = Point_of_tri(tris[j]);
			    if(p1[0] == p[i] || p1[1] == p[i] || p1[2] == p[i])
				break;
			}
		
			//p is a point of tri on ref bdry
			if(j<num)
			{
			    tris[nt++] = tri;
			    if(nt >= MAX_SUBDOMAIN_TRIS)
			    {
				printf("ERROR sep_common_pt_for_ref_bdry,"
				       " too many tris in the second.\n ");
				clean_up(ERROR);
			    }
			    break;
			}
		    }
		}
	    }
	}
	
	tmp_fac = get_comm_pt_fac();
	set_comm_pt_fac(0.999);
	if(nt > 0)
	    sep_common_point_from_loop(tris, nt, NULL, NULL, intfc);
	set_comm_pt_fac(tmp_fac);
}

void cut_buffer_tris_from_intfc(
	INTERFACE	*intfc,
	int		dir,
	int		nb)
{
	SURFACE		**s;
	RECT_GRID	*gr = computational_grid(intfc);
	INTERFACE	*sav_intfc;
	
	sav_intfc = current_interface();

	set_current_interface(intfc);

	for (s = intfc->surfaces; s && *s; ++s)
	    cut_buffer_tris(*s, gr, dir, nb);
	
	{
	CURVE	**c;
	BOND	*bs;
	BOND_TRI	**btris;

	for (c = intfc->curves; c && *c; ++c)
	{
	    //printf("#c = %d\n", *c);
	    for (bs = (*c)->first; bs != NULL; bs = bs->next)
	    {
		btris = Btris(bs);
	        //printf("btris %d  %d  | ", bs, btris);
		if(btris != NULL && *btris == NULL)
		{
		    printf(" #  ");
		    Btris(bs) = NULL;
		}
		//for(btris = Btris(bs); btris && *btris; btris++)
		//    printf(" %d ", *btris);
		//printf("\n");
	    }
	}
	}

	cut_out_curves_in_buffer(intfc);

	set_current_interface(sav_intfc);
}

int cut_buffer_tris(
	SURFACE		*surf,
	RECT_GRID	*grid,
	int		dir,
	int		nb)
{
	TRI	   *tri, *nbtri;
	int	   ns, i, j;
	float	   crx_coord;
	static TRI **tris_s = NULL;
	static int len_tris_s = 0;
	POINT	   **p;

	DEBUG_ENTER(cut_bubber_tris)
	
	if (len_tris_s < surf->num_tri)
	{
	    len_tris_s = surf->num_tri;
	    if (tris_s != NULL)
		free(tris_s);
	    uni_array(&tris_s,len_tris_s,sizeof(TRI *));
	}

	crx_coord = (nb == 0) ? grid->L[dir] : grid->U[dir];

	for (tri=first_tri(surf); !at_end_of_tri_list(tri,surf); tri=tri->next)
	    Tri_order(tri) = 0;

	flag_point_pos(crx_coord, dir, nb, surf, surf->interface);

	ns = 0;
	for (tri=first_tri(surf); !at_end_of_tri_list(tri,surf); tri=tri->next)
	{
	    //if (tri_cross_line(tri,crx_coord,dir) == YES || 
		//tri_bond_cross_test(tri,crx_coord,dir) == YES)
	   
	    //on reflect bdry and 3comp curve is perpendicular to the ref plane,
	    //this condition is enough 
	    if (tri_cross_line(tri,crx_coord,dir) == YES)
	    {
		tris_s[ns++] = tri;
		for(i=0; i<3; i++)
		{
		    if(!is_side_bdry(tri,i))
		    {
		        nbtri = Tri_on_side(tri,i);
			if(nbtri != NULL)
			{
			    for(j=0; j<3; j++)
				if(!is_side_bdry(nbtri,j) && 
				    Tri_on_side(nbtri,j) == tri)
				    Tri_order(nbtri) |= Bin_side(j);
		        }
		    }
		}

		if(the_tri(tri))
		{
		    printf("#the_tri found\n");
		    print_tri(tri, surf->interface);
		}
	    }

	    p = Point_of_tri(tri);
	    if(Point_order(p[0]) == -2 && 
	       Point_order(p[1]) == -2 && Point_order(p[2]) == -2)
		tris_s[ns++] = tri;
	}
	
	for(i=0; i<ns; i++)
	    //remove_out_domain_tri(tris_s[i], surf);
	    remove_tri_from_surface(tris_s[i], surf, NO);

	/*
	for (tri=first_tri(surf); !at_end_of_tri_list(tri,surf); tri=tri->next)
	{
	    for(j=0; j<3; j++)
		if(!is_side_bdry(tri,j) && 
		    (Tri_order(tri) & Bin_side(j)) != 0 )
		    printf("#tri %d  %d  %d\n", Tri_on_side(tri,j), tri, j);
	}
	*/
	//DEBUG_TMP printf("#nsna  %d  %d\n", ns, na);
	
	DEBUG_LEAVE(cut_buffer_tris)
	return YES;
}		/*end append_buffer_surface1*/




void tecplot_surface_curve(FILE*, SURFACE*);
char *  get_directory();

LOCAL int append_buffer_surface1(
	SURFACE		*surf,
	SURFACE		*adj_surf,
	RECT_GRID	*grid,
	int		dir,
	int		nb,
	P_LINK		*p_table,
	int		p_size)
{
	SURFACE    *new_adj_surf;
	TRI	   *tri, *tri1;
	CURVE	   **c;
	int	   ns, na, new_na, i;
	float	   crx_coord;
	static TRI **tris_s = NULL, **tris_a = NULL;
	static int len_tris_s = 0, len_tris_a = 0;

	DEBUG_ENTER(append_buffer_surface1)

	if (DEBUG)
	{
	    (void) printf("dir = %d,nb = %d\n",dir,nb);
	    (void) printf("My surface\n");
	    print_surface(surf);
	    (void) printf("Buffer surface\n");
	    print_surface(adj_surf);
	}
	
	//#bjet2
	if(debugging("out_surf"))
	{
	    char   s[40];
	    
	    printf("#check curve_surf\n");
	    check_surface_curve(surf);
	    printf("#check_curve adj_surf\n");
	    check_surface_curve(adj_surf);

	    sprintf(s, "surf_%d", pp_mynode());
	    tecplot_surface(s, NULL, surf);
	    sprintf(s, "adj_surf_%d", pp_mynode());
	    tecplot_surface(s, NULL, adj_surf);
	}

	if (len_tris_s < surf->num_tri)
	{
	    len_tris_s = surf->num_tri;
	    if (tris_s != NULL)
		free(tris_s);
	    uni_array(&tris_s,len_tris_s,sizeof(TRI *));
	}
	if (len_tris_a < adj_surf->num_tri)
	{
	    len_tris_a = adj_surf->num_tri;
	    if (tris_a != NULL)
		free(tris_a);
	    uni_array(&tris_a,len_tris_a,sizeof(TRI *));
	}

	crx_coord = (nb == 0) ? grid->L[dir] : grid->U[dir];

	//printf("crx_coord = %24.15e\n", crx_coord);

	ns = na = 0;
	for (tri=first_tri(surf); !at_end_of_tri_list(tri,surf); tri=tri->next)
	{
	    if (tri_cross_line(tri,crx_coord,dir) == YES || 
		tri_bond_cross_test(tri,crx_coord,dir) == YES)
	    {
		tris_s[ns++] = tri;
		if(the_tri(tri))
		{
		    printf("#the_tri found\n");
		    print_tri(tri, surf->interface);
		}
	    }
	}

	for (tri = first_tri(adj_surf); !at_end_of_tri_list(tri,adj_surf); 
	     tri = tri->next)
	{
	    if (tri_cross_line(tri,crx_coord,dir) == YES ||
		tri_bond_cross_test(tri,crx_coord,dir) == YES)
		tris_a[na++] = tri;
	}

	// Add matching points to the hashing table p_table
	// DEBUG_TMP printf("#nsna  %d  %d\n", ns, na);
	
	if(debugging("out_matching"))
	//if(ns == 110 && pp_mynode() == 1)
	//if(debugging("ref_tst") && ns == 32)
	{
	    FILE  *fp;
	    char  s[50];
		    
	    sprintf(s, "app_buff_%d.plt", pp_mynode());

	    fp = fopen(s, "w");
	    printf("#show tris_s and tris_a\n");

	    tecplot_show_tris("ns", tris_s, ns, fp);
	    tecplot_show_tris("na", tris_a, na, fp);
	    
	    tecplot_surface(NULL, fp, surf);
	    tecplot_surface(NULL, fp, adj_surf);

	    fclose(fp);
	}

	if (add_matching_pt_to_hash_table(tris_s,tris_a,ns,na,surf,
		      adj_surf,p_table,p_size))
	{
	    new_adj_surf = copy_buffer_surface(adj_surf,p_table,p_size);
	}
	else 
	{
	    screen("WARNING in append_buffer_surface1(), can't match "
	           "tris on with buffer surface\n");
	    FILE  *fp;
	    char  s[50];
		    
	    sprintf(s, "app_nsna_%d.plt", pp_mynode());
	    printf("#error surface file %s\n", s);

	    fp = fopen(s, "w");
	    tecplot_show_tris("ns", tris_s, ns, fp);
	    tecplot_show_tris("na", tris_a, na, fp);
	    
	    tecplot_surface(NULL, fp, surf);
	    tecplot_surface(NULL, fp, adj_surf);
	    fclose(fp);
	    
	    //clean_up(ERROR);
	    return NO;
	}

	synchronize_tris_at_subdomain_bdry(tris_a,tris_s,ns,p_table,p_size);

	//tris on adj_surf and new_adj_surf have the same order,
	//see copy_tris
	for (tri = first_tri(adj_surf); !at_end_of_tri_list(tri,adj_surf);
	     tri = tri->next)
	{
	    Tri_index(tri) = 0;
	}
	for(i=0; i<na; i++)
	    Tri_index(tris_a[i]) = 1;
	
	na = 0;
	for (tri=first_tri(new_adj_surf), tri1=first_tri(adj_surf); 
	     !at_end_of_tri_list(tri,new_adj_surf) && 
	     !at_end_of_tri_list(tri1,adj_surf);
	     tri = tri->next, tri1 = tri1->next)
	{
	    if(Tri_index(tri1) == 1)
		tris_a[na++] = tri;
	}

	adj_surf = new_adj_surf;
	
	/*adjoin adj_surf tri list to surf tri list */
	last_tri(surf)->next = first_tri(adj_surf);
	first_tri(adj_surf)->prev = last_tri(surf);
	link_tri_list_to_surface(first_tri(surf),last_tri(adj_surf),surf);
	
	//#bjet2  BEGIN curves in adj_surf should be added to surf. 
	for(c=adj_surf->pos_curves; c && *c; c++)
	    if(! delete_from_pointers(adj_surf, &(*c)->pos_surfaces))
	    {
	        printf("ERROR: in append_buffer_surface1, "
		       "adj_surf and pos_curves are not paired.\n");
		clean_up(ERROR);
	    }
	    else
	        install_curve_in_surface_bdry(surf, *c, POSITIVE_ORIENTATION);

	for(c=adj_surf->neg_curves; c && *c; c++)
	    if(! delete_from_pointers(adj_surf, &(*c)->neg_surfaces))
	    {
	        printf("ERROR: in append_buffer_surface1, "
		       "adj_surf and neg_curves are not paired.\n");
		clean_up(ERROR);
	    }
	    else
	        install_curve_in_surface_bdry(surf, *c, NEGATIVE_ORIENTATION);
	//#bjet2 END

	adj_surf->pos_curves = adj_surf->neg_curves = NULL;
	(void) delete_surface(adj_surf);
	adj_surf = NULL;

	// DEBUG_TMP printf("#nsna1  %d  %d\n", ns, na);

	if(NO)
	{
	    int	i;
	    
	    for(i=0; i<ns; i++)
	        if(the_side(tris_s[i]))
		{
		    printf("#tris_a found\n");
	            print_tri(tris_s[i], surf->interface);
		}
	}

	//#bjet2  average_btris
	if (!match_tris_at_subdomain_bdry(surf,adj_surf,tris_s,tris_a,ns,na))
	{
	    (void) printf("WARNING in append_buffer_surface1(), "
	                  "no match of tris at subdomain\n");
	    (void) printf("dir = %d, nb = %d\n",dir,nb);
	    //print_rectangular_grid(grid);
	    DEBUG_LEAVE(append_buffer_surface1)
	    return NO;
	}

	DEBUG_LEAVE(append_buffer_surface1)
	return YES;
}		/*end append_buffer_surface1*/


LOCAL	void	synchronize_tris_at_subdomain_bdry(
	TRI    **tris_a,
	TRI    **tris_s,
	int    nt,
	P_LINK *p_table,
	int    p_size)
{
	POINT **ps, **pa, *p0, *p1, *p2;
	TRI   *ts, *ta;
	int   i, j, id, idp, idn;

	for (i = 0; i < nt; ++i)
	{
	    ts = tris_s[i];
	    ps = Point_of_tri(ts);
	    for (j = 0; j < nt; ++j)
	    {
		ta = tris_a[j];
		pa = Point_of_tri(ta);
		for (id = 0; id < 3; ++id)
		{
		    //p0 = (POINT*) find_from_hash_table((POINTER)pa[id],
		    //			       p_table,p_size);
		    p0 = (POINT*)Cor_point(pa[id]);

		    if (p0 == ps[0])
		    {
		        idn = Next_m3(id);
		        //p1 = (POINT*) find_from_hash_table((POINTER)pa[idn],
			//			           p_table,p_size);
			p1 = (POINT*)Cor_point(pa[idn]);
		        
			if (p1 == ps[1])
		        {
		            idp = Prev_m3(id);
		            //p2 = (POINT*) find_from_hash_table((POINTER)pa[idp],
			    //		               p_table,p_size);
			    p2 = (POINT*)Cor_point(pa[idp]);
			    
			    if (p2 == ps[2])
			    {
			        if(NO && the_tri(ta))
				{
				    printf("#sync tris  \n");
				    print_tri(ts, ts->surf->interface);
				    print_tri(ta, ta->surf->interface);
				    add_to_debug("ts_tst");
				}

			        rotate_triangle(ts,(3-id)%3);
				
				if(NO && debugging("ts_tst"))
				{
				    printf("#sync tris af\n");
				    print_tri(ts, ts->surf->interface);
				    remove_from_debug("ts_tst");
				}
			        //set_normal_of_tri(ts);
			        //set_normal_of_tri(ta);
			        break;
			    }
		        }
		    }
		}
		if (id < 3)
		    break;
	    }
	    if(j == nt)
	    {
	        printf("WARNING, synchronize_tris_at_subdomain_bdry, "
		       "suitable triangle is not found.\n");
	        print_tri(ts, ts->surf->interface);
	    }
	}
}		/*end synchronize_tris_at_subdomain_bdry*/

LOCAL	bool	tri_cross_line(
	TRI		*tri,
	float		crx_coord,
	int		dir)
{
	float	min_coord, max_coord;
	float	crx_tol = tol1[dir];

	min_coord = max_coord = Coords(Point_of_tri(tri)[0])[dir];

	if (min_coord > Coords(Point_of_tri(tri)[1])[dir])
	    min_coord = Coords(Point_of_tri(tri)[1])[dir];
	if (min_coord > Coords(Point_of_tri(tri)[2])[dir])
	    min_coord = Coords(Point_of_tri(tri)[2])[dir];

	if (max_coord < Coords(Point_of_tri(tri)[1])[dir])
	    max_coord = Coords(Point_of_tri(tri)[1])[dir];
	if (max_coord < Coords(Point_of_tri(tri)[2])[dir])
	    max_coord = Coords(Point_of_tri(tri)[2])[dir];
	
	return (((min_coord - crx_coord) <= crx_tol) && 
	        ((crx_coord - max_coord) <= crx_tol)) ? YES : NO;
}		/*end tri_cross_line*/

//#bjet2
//NO    no bond side or no tri crx line
//YES   one tri crx line
LOCAL	bool	tri_bond_cross_line(
	TRI		*tri,
	float		crx_coord,
	int		dir)
{
int		i;
BOND		*b;
BOND_TRI	**btris;

	for(i=0; i<3; i++)
	{
	    if(!is_side_bdry(tri, i))
	        continue;
	    b = Bond_on_side(tri, i);
	    for(btris = Btris(b); btris && *btris; btris++)
	    	if(tri_cross_line((*btris)->tri,crx_coord,dir))
	            return YES;
	}
	return NO;
}

LOCAL	bool ref_append = NO;
void	set_ref_append(bool);

void	set_ref_append(bool fg)
{
	ref_append = fg;
}


LOCAL bool tri_bond_cross_test(
	TRI		*tri,
	float		crx_coord,
	int		dir)
{
int	i, j, n;
TRI	**tris;
POINT	*p;

	if(ref_append)
	    return NO;

	if(tri_bond_cross_line(tri,crx_coord,dir))
	    return YES;
	j = 0;
	for(i=0; i<3; i++)
	{
	    if(Boundary_point(Point_of_tri(tri)[i]))
	    {
	        p = Point_of_tri(tri)[i];
	        j++;
	    }
	}

	if(j != 1)
	    return NO;
	n = set_tri_list_around_point(p, tri, &tris, tri->surf->interface);
	
	if(tri_bond_cross_line(tris[0],crx_coord,dir) ||
	   tri_bond_cross_line(tris[n-1],crx_coord,dir) )
	    return YES;
	return NO;
}

LOCAL bool match_tris_at_subdomain_bdry(
	SURFACE		*surf,
	SURFACE		*adj_surf,
	TRI		**tri_s,
	TRI		**tri_a,
	int		ns,
	int		na)
{
	TRI		*ta, *ts;
	int		i, j;
	int		ums,uma;
	static bool	*ms = NULL, *ma = NULL;
	static int      ms_len = 0, ma_len = 0;

	DEBUG_ENTER(match_tris_at_subdomain_bdry)
	if (DEBUG)
	{
	    (void) printf("Entered match_tris_at_subdomain_bdry()\n");
	    (void) printf("tri_a: na=%d\n",na);
	    for (i = 0; i < na; ++i)
		print_tri(tri_a[i],adj_surf->interface);
	    (void) printf("tri_s: ns=%d\n",ns);
	    for (i = 0; i < ns; ++i)
		print_tri(tri_s[i],surf->interface);
	}

	if (ms_len < ns)
	{
	    ms_len = ns;
	    if (ms != NULL)
		free(ms);
	    uni_array(&ms,ms_len,sizeof(bool));
	}
	if (ma_len < na)
	{
	    ma_len = na;
	    if (ma != NULL)
		free(ma);
	    uni_array(&ma,ma_len,sizeof(bool));
	}

	for (i = 0; i < ns; ++i)
	    ms[i] = NO;
	for (i = 0; i < na; ++i)
	    ma[i] = NO;

	for (i = 0; i < na; ++i)
	{
	    ta = tri_a[i];
	    if(the_tri(ta))
	    {
	        printf("#append tri\n");
		print_tri(ta, surf->interface);
		add_to_debug("app_tri");
	    }
	    
	    for (j = 0; j < ns; ++j)
	    {
	        ts = tri_s[j];
	        if (match_two_tris(ts,ta))
		{
		    ma[i] = ms[j] = YES;
		    
		    if(debugging("app_tri"))
		        printf("ns  %d \n", j);

		    //#bjet2
	    	    average_btris(ts, surf, ta, adj_surf);
		    merge_two_tris(ts,ta,surf,adj_surf);
		    break;
		}
	    }

	    remove_from_debug("app_tri");
	}
	ums = uma = 0;
	for (i = 0; i < ns; ++i)
	    if (ms[i] == NO)
		++ums;
	for (i = 0; i < na; ++i)
	    if (ma[i] == NO)
		++uma;
	if (ums != 0 || uma != 0)
	{
	    return NO;
	    (void) printf("WARNING in match_tris_at_subdomain_bdry(), "
	                  "unmatched local tris\n"
	                  "na = %d ns = %d\n"
	                  "ums = %d uma = %d\n",na,ns,ums,uma);
	    for (i = 0; i < ns; ++i)
	    	if (ms[i] == NO)
		    print_tri(tri_s[i],surf->interface);
	    (void) printf("unmatched adj tris:\n");
	    for (i = 0; i < na; ++i)
	    	if (ma[i] == NO)
		    print_tri(tri_a[i],adj_surf->interface);
	    
	    DEBUG_LEAVE(match_tris_at_subdomain_bdry)
	    clean_up(ERROR);
	    return NO;
	}

	DEBUG_LEAVE(match_tris_at_subdomain_bdry)
	return YES;
}		/*end match_tris_at_subdomain_bdry*/

/*
*			match_two_tris():
*
*	Determines whether two triangles are the same triangle up to a rotation
*	of the vertex indices.  Returns YES if the tris are the same,
*	otherwise returns NO.
*/

LOCAL bool match_two_tris(
	TRI		*tri,
	TRI		*atri)
{
	int		j;
	POINT		**p, **ap;

	p = Point_of_tri(tri);
	ap = Point_of_tri(atri);
	for (j = 0; j < 3; ++j)
	    if (p[0] == ap[j])
		break;
	if (j == 3)
	    return NO;
	return ((p[1]==ap[Next_m3(j)]) && (p[2]==ap[Prev_m3(j)])) ? YES : NO;
}		/*end match_two_tris*/

/*
*			merge_two_tris():
*
*	Merges two triangles ts and ta by replacing all linking
*	information to and from ta by linking with ts  while preserving
*	any nontrivial linking information in ts.
*/

//#bjet2
EXPORT	void merge_two_tris(
	TRI	*ts,
	TRI	*ta,
	SURFACE	*s,
	SURFACE *as)
{
	TRI		*tri;
	BOND_TRI	*btri;
	int		i, j;

	DEBUG_ENTER(merge_two_tris)
	if (DEBUG)
	{
	    print_tri(ts,s->interface);
	    print_tri(ta,as->interface);
	}

	/* Set the links on the null side of ts by corresponding links to ta*/
	for (i = 0; i < 3; ++i)
	{
	    // #bjet2  for grid based, this part is not necessary
            if(is_side_bdry(ta,i))
            {
	       if(Bond_on_side(ts,i) == NULL)
               {
                       if(Bond_on_side(ta,i) == NULL)
                           continue;
		       
	       	       printf("#merge_two_tris: bond on block face.\n");
		       //set tri_neighbor btri
                       Bond_tri_on_side(ts,i) = btri = Bond_tri_on_side(ta,i);
                       btri->tri = ts;
                       btri->surface = s;
               }
	       continue;
            }

	    if(the_tri(ta) || the_tri(ts))
	    {
	        printf("#match two tris\n");
		print_tri(ts, s->interface);
		print_tri_states(ts, Hyper_surf(s));

		printf("#app tri\n");
		print_tri(ta, s->interface);
		print_tri_states(ta, Hyper_surf(s));
	    }

	    if (Tri_on_side(ts,i) == NULL)
	    {
	    	if (Tri_on_side(ta,i) == NULL)
		{
		    /*
		    printf("#two null\n");
		    print_tri(ts, s->interface);
		    print_tri_states(ts, Hyper_surf(s));
		    
		    printf("#ta tri\n");
		    print_tri(ta, s->interface);
		    print_tri_states(ta, Hyper_surf(s));
	    	    */
		    continue;
		}
		// set tri_neighbor tri
	    	Tri_on_side(ts,i) = tri = Tri_on_side(ta,i);
	    	if(the_tri(tri))
		{
		    printf("#triset\n");
		    print_tri(ta, s->interface);
		    print_tri(ts, s->interface);
		}
		
		for (j = 0; j < 3; ++j)
	    	{
	    	    if (Tri_on_side(tri,j) == ta)
	    	    	Tri_on_side(tri,j) = ts;
	    	}
	    }
	}
	
	//remove ta from s tri list
	remove_tri_from_surface(ta,s,NO);
	if (DEBUG)
	{
	    (void) printf("after merge_two_tris\n");
	    print_tri(ts,s->interface);
	}
	DEBUG_LEAVE(merge_two_tris)
}		/*end merge_two_tris*/



/*
*			add_matching_pt_to_hash_table():
*
*	Creates a hashed list of matching points on intfc and adj_intfc,
*	where two points match if their positions are within a prescribed
*	floating point tolerance.  This is an extremely expensive function
*	and should be a candidate for an improved version.
*/

LOCAL bool add_matching_pt_to_hash_table(
	TRI 	**tris_s,
	TRI	**tris_a,
	int	ns,
	int 	na,
	SURFACE	*ss,
	SURFACE	*sa,
	P_LINK	*p_table,
	int	p_size)
{
	bool                  status;
	int 	                 i, tstn;
	POINT_LIST               *plists, *plista, *pls, *pla;
	static POINT_LIST_STORE  Pslist_store, Palist_store;

	//reset_hash_table(p_table,p_size);
	//printf("#tris_s  \n");
	plists = set_point_list(tris_s,ns,Hyper_surf(ss),&Pslist_store);
	//printf("#tris_a  \n");
	plista = set_point_list(tris_a,na,Hyper_surf(sa),&Palist_store);

	tstn = 0;
	status = YES;
	for (pls = plists; pls != NULL; pls = pls->next)
	{
	    for (pla = plista; pla != NULL; pla = pla->next)
	    {
		for (i = 0; i < 3; ++i) /*Floating point TOLERANCE test*/
	            if (fabs(Coords(pla->p)[i]-Coords(pls->p)[i]) > tol_pt[i])
			break;
		if (i == 3)
		{
		    tstn++;

		    if(the_point(pls->p))
		    {
		        printf("#match point  %d %d \n", pls->p, pla->p);
			//print_general_vector("tol", tol_pt, 3, "\n");
			print_general_vector("ps", Coords(pls->p), 3, "\n");
			print_general_vector("pa", Coords(pla->p), 3, "\n");
		    }

	            (void) add_to_hash_table((POINTER)pla->p,(POINTER)pls->p,
				             p_table,p_size);
		    Cor_point(pla->p) = (POINTER) pls->p;

		    set_full_average(NO);
		    (void) average_points(NO,pla->p,pla->hse,pla->hs,
				          pls->p,pls->hse,pls->hs);
		    set_full_average(YES);
		    
		    if (pla->prev == NULL)
			plista = pla->next;
		    else
			pla->prev->next = pla->next;
		    if (pla->next != NULL)
			pla->next->prev = pla->prev;
		    break;
		}
	    }
	    //can not find a corresponding point in plista, in this case, we continue search
	    //just set status = NO.
	    if (pla == NULL) 
	        status = NO;
	}
	if (plista != NULL)
	    status = NO;

	if(status == NO)
	{
	    float	*pa, *ps;
	    float	len, min_len;

	    printf("add_matching_pt_to_hash_table: check nearest point pairs\n");

	    for (pla = plista; pla != NULL; pla = pla->next)
	    {
	        min_len = HUGE_VAL;
		for (pls = plists; pls != NULL; pls = pls->next)
	        {
		    len = distance_between_positions(Coords(pla->p), Coords(pls->p), 3);
		    if(len < min_len)
		    {
		        min_len = len;
			pa = Coords(pla->p);
			ps = Coords(pls->p);
		    }
		}
		
		print_general_vector("pa", pa, 3, "\n");
		print_general_vector("ps", ps, 3, "\n");
	    }
	}

	//printf("#status %d %d\n", status, tstn);
	
	return (ns == na) ? status : NO;
}		/*end add_matching_pt_to_hash_table*/

bool the_tri_rot(TRI *);

LOCAL	POINT_LIST	*set_point_list(
	TRI	         **tris,
	int              nt,
	HYPER_SURF       *hs,
	POINT_LIST_STORE *plist_store)
{
	POINT      **p;
	POINT_LIST *plist, *pl, Plist;
	TRI        *tri;
	int        i, j, max_np, tstnum;

	tstnum = 0;
	if (nt == 0)
	    return NULL;
	max_np = 3*nt + 1;
	if (max_np > plist_store->len)
	{
	    if (plist_store->pl != NULL)
		free(plist_store->pl);
	    plist_store->len = max_np;
	    uni_array(&plist_store->pl,sizeof(POINT_LIST),plist_store->len);
	}
	zero_scalar(plist_store->pl,sizeof(POINT_LIST)*plist_store->len);
	for (i = 0; i < nt; ++i)
	{
	    p = Point_of_tri(tris[i]);
	    for (j = 0; j < 3; ++j)
	        sorted(p[j]) = NO;
	}

	plist = plist_store->pl;
	pl = &Plist;
	for (i = 0; i < nt; ++i)
	{
	    tri = tris[i];
	    
	    if(the_tri_rot(tri))
	    {
	        printf("set_point_list\n");
	        print_tri(tri, hs->interface);
	    }

	    p = Point_of_tri(tri);
	    for (j = 0; j < 3; ++j)
	    {
		if (!sorted(p[j]))
		{
		    pl->next = plist++;
		    pl->next->prev = pl;
		    pl = pl->next;
	            pl->p = p[j];
	            pl->hs = hs;
	            pl->hse = Hyper_surf_element(tri);
	            sorted(pl->p) = YES;
		    tstnum++; 
		}
	    }
	}
	Plist.next->prev = NULL;

	//printf("#tstnum  %d\n", tstnum);
	
	return Plist.next;
}		/*end set_point_list*/

//copy surface as to s and replace the points in p_table in surface s.
//It will also put the new generated points in p_table.
EXPORT	SURFACE *copy_buffer_surface(
	SURFACE		*as,
	P_LINK		*p_table,
	int		p_size)
{
	SURFACE		*s;
	POINT		*p, *np, *ap;
	TRI		*tri, *atri;
	CURVE		**c, **pos_curves = NULL, **neg_curves = NULL;
	int		i;

	DEBUG_ENTER(copy_buffer_surface)

	/* First identify and copy nodes on as */

	for (c = as->pos_curves; c && *c; ++c)
	{
	    if (!add_to_pointers(matching_curve(*c,p_table,p_size),
				    &pos_curves))
	    {
	        screen("ERROR in copy_buffer_surface(), "
	               "add_to_pointers() failed\n");
	        clean_up(ERROR);
	    }
	}
	for (c = as->neg_curves; c && *c; ++c)
	{
	    if (!add_to_pointers(matching_curve(*c,p_table,p_size),
				    &neg_curves))
	    {
	        screen("ERROR in copy_buffer_surface(), "
	               "add_to_pointers() failed\n");
	        clean_up(ERROR);
	    }
	}

	/* set tri_array_numbers */
	for(i=0, tri=first_tri(as); !at_end_of_tri_list(tri,as); tri=tri->next)
	    Tri_index(tri) = i++;

	s = copy_surface(as,pos_curves,neg_curves,YES);

	/* null_tri_array_numbers */
	for(i=0, tri=first_tri(as); !at_end_of_tri_list(tri,as); tri=tri->next)
	    Tri_index(tri) = 0;

	for (tri = first_tri(s); !at_end_of_tri_list(tri,s); tri = tri->next)
	{
	    sorted(Point_of_tri(tri)[0]) = NO;
	    sorted(Point_of_tri(tri)[1]) = NO;
	    sorted(Point_of_tri(tri)[2]) = NO;
	}
	for (tri = first_tri(s), atri = first_tri(as);
	     !at_end_of_tri_list(tri,s); tri = tri->next, atri = atri->next)
	{
	    for (i = 0; i < 3; ++i)
	    {
	    	p = Point_of_tri(tri)[i];
	    	if (sorted(p) == NO)
	    	{
	    	    if (!vertex_on_bond(tri,i))  //#bjet2 the if is useless
		    {
			ap = Point_of_tri(atri)[i];
			np = (POINT*)find_from_hash_table((POINTER)ap,
					                  p_table,p_size);
			if (np == NULL)
			{
			    (void) add_to_hash_table((POINTER)ap,(POINTER)p,
						     p_table,p_size);
			}
			else if (p != np)
			{
			    p = np;
			    Point_of_tri(tri)[i] = p;
			}
		    }
		    sorted(p) = YES;
		}
	    }
	}
	DEBUG_LEAVE(copy_buffer_surface)
	return s;
}		/*end copy_buffer_surface*/

//#bjet2
EXPORT	CURVE *matching_curve(
	CURVE		*ac,
	P_LINK		*p_table,
	int		p_size)
{
	BOND		*b, *ab;
	CURVE		**cc, *c;
	NODE		*ns, *ne;
	POINT		*ap, *p;

	ns = matching_node(ac->start,p_table,p_size);
	ne = matching_node(ac->end,p_table,p_size);
	for (cc = ns->out_curves; cc && *cc; ++cc)
	    if (curves_match(*cc,ac,p_table,p_size))
	        return *cc;
	
	c = copy_curve(ac,ns,ne);
	
	//matching_node already put the starting and ending points in the hash table
	//do not deal the starting and the ending points here.
	for (b = c->first, ab = ac->first; b != c->last && ab != ac->last;
		b = b->next, ab = ab->next)
	{
	    ap = ab->end;
	    p = (POINT*) find_from_hash_table((POINTER)ap,p_table,p_size);
	    if (p != NULL)
	    {
	    	b->end = p;
		if (b->next)
	    	    b->next->start = p;
	    }
	    else
	    	(void) add_to_hash_table((POINTER)ap,(POINTER)b->end,
					 p_table,p_size);
	}
	
	test_curve_link(c);

	return c;
}		/*end matching_curve*/

EXPORT	bool curves_match(
	CURVE		*c,
	CURVE		*ac,
	P_LINK		*p_table,
	int		p_size)
{
	BOND		*b, *ab;
	POINT		*p, *ap;

	ap = ac->start->posn;
	p = (POINT*)find_from_hash_table((POINTER)ap,p_table,p_size);
	if (p != c->start->posn)
	    return NO;
	for (b = c->first, ab = ac->first; b && ab; b = b->next, ab = ab->next)
	{
	    ap = ab->end;
	    p = (POINT*)find_from_hash_table((POINTER)ap,p_table,p_size);
	    if (p != b->end)
		return NO;
	}
	
	//#bjet2
	if(ab == NULL)
	    return YES;	 //curve in orginal intfc is longer or equal
	return NO;
}		/*end curves_match*/

EXPORT	NODE *matching_node(
	NODE		*an,
	P_LINK		*p_table,
	int		p_size)
{
	INTERFACE	*intfc = current_interface();
	NODE		*newn;
	POINT		*p, *ap = an->posn;

	p = (POINT*)find_from_hash_table((POINTER)ap,p_table,p_size);
	if (p == NULL)
	{
	    p = copy_point(ap);
	    (void) add_to_hash_table((POINTER)ap,(POINTER)p,p_table,p_size);
	}
	newn = node_of_point(p,intfc);
	if (newn == NULL)
	    newn = make_node(p);
	return newn;
}		/*end matching_node*/

EXPORT void open_null_sides1(
	INTERFACE	*intfc,
	float		*L,
	float		*U,
	int		dir,
	int		nb)
{
	TRI		*tri;
	SURFACE 	**s;
	DEBUG_ENTER(open_null_sides1)

	if (DEBUG)
	{
	    char	      dname[1024];
	    static const char *xyz[] = { "x", "y", "z"};
	    static const char *sname[] = { "lower", "upper"};
	    static const char *strdir[3] = { "X", "Y", "Z" };
	    static const char *strnb[2] = { "LOWER", "UPPER" };
	    static int into[3][2];
	    (void) printf("Clipping interface in at %s %s side\n",
			  sname[nb],xyz[dir]);
	    (void) printf("U = ( %g %g %g )\n",U[0],U[1],U[2]);
	    (void) printf("L = ( %g %g %g )\n",L[0],L[1],L[2]);
	    (void) sprintf(dname,"fscatter/open_null_sides1/Into%d-%s_%s",
			   into[dir][nb],strdir[dir],strnb[nb]);
	    ++into[dir][nb];
	    summarize_interface(dname,"before",intfc,XY_PLANE,
				"open_null_sides1","before");
	}
	/*
	if (!buffered_boundary_type(rect_boundary_type(intfc,dir,nb)))
	{
	    DEBUG_LEAVE(open_null_sides1)
	    return;
	}
	*/

	for (s = intfc->surfaces; s && *s; ++s)
	{
	    TRI *ntri = NULL;
	    for (tri=first_tri(*s); !at_end_of_tri_list(tri,*s); tri=ntri)
	    {
		ntri = tri->next;
	    	//#bjet2  bond with inside tri survives.
		if (tri_out_domain1(tri,L,U,dir,nb) && 
		    tri_bond_test(tri,L,U,dir,nb))
	    	    remove_out_domain_tri(tri,*s);
	    }
	}
	for (s = intfc->surfaces; s && *s; ++s)
	{
	    if (no_tris_on_surface(*s))
	    {
	    	(void) delete_surface(*s);
		--s;
	    }
	}
	DEBUG_LEAVE(open_null_sides1)
}		/*end open_null_sides1*/

EXPORT void remove_out_domain_tri(
	TRI		*tri,
	SURFACE		*s)
{
	TRI		*nbtri;
	int		i;

	for (i = 0; i < 3; ++i)
	{
	    if (!is_side_bdry(tri,i))
	    {
		nbtri = Tri_on_side(tri,i);
		if (nbtri != NULL)
		{
		    if (Tri_on_side01(nbtri) == tri)
		    	Tri_on_side01(nbtri) = NULL;
		    else if (Tri_on_side12(nbtri) == tri)
		    	Tri_on_side12(nbtri) = NULL;
		    else if (Tri_on_side20(nbtri) == tri)
		    	Tri_on_side20(nbtri) = NULL;
		}
	    }
	    else
	    {
		BOND_TRI *bt = Bond_tri_on_side(tri,i);
		if (bt != NULL)
		    (void) delete_from_pointers(bt,&Btris(bt->bond));
	    }
	}
	remove_tri_from_surface(tri,s,NO);
}		/*end remove_out_domain_tri*/


LOCAL bool tri_out_domain1(
	TRI		*tri,
	float		*L,
	float		*U,
	int		dir,
	int		nb)
{
	POINT **p;
	int   i;

	p = Point_of_tri(tri);
	if (nb == 0)
	{
	    for (i = 0; i < 3; ++i)
	    {
		if ((L[dir] - Coords(p[i])[dir]) <= tol1[dir])
	    	    return NO;
	    }
	}
	else
	{
	    for (i = 0; i < 3; ++i)
	    {
		if ((Coords(p[i])[dir] - U[dir]) <= tol1[dir])
	    	    return NO;
	    }
	}
	return YES;
}	/* end tri_out_domain1 */

//#bjet2  
LOCAL bool tri_bond_out_domain(
	TRI		*tri,
	float		*L,
	float		*U,
	int		dir,
	int		nb)
{
int		i;
BOND		*b;
BOND_TRI	**btris;

	for(i=0; i<3; i++)
	{
	    if(!is_side_bdry(tri, i))
	        continue;
	    b = Bond_on_side(tri, i);
	    for(btris = Btris(b); btris && *btris; btris++)
	        if(!tri_out_domain1((*btris)->tri, L, U, dir, nb))
		    return NO;
	}
	return YES;
}

LOCAL bool tri_bond_test(
	TRI		*tri,
	float		*L,
	float		*U,
	int		dir,
	int		nb)
{
int	i, j, n;
TRI	**tris;
POINT	*p;

	if(!tri_bond_out_domain(tri,L,U,dir,nb))
	    return NO;
	j = 0;
	for(i=0; i<3; i++)
	{
	    if(Boundary_point(Point_of_tri(tri)[i]))
	    {
	        p = Point_of_tri(tri)[i];
	        j++;
	    }
	}

	//j == 0 tri has no boundary point, return YES.
	//j > 1  tri has a outside domain bond return YES.
	if(j != 1)
	    return YES;
	n = set_tri_list_around_point(p, tri, &tris, tri->surf->interface);

	//tris[0] or tris[n-1] has a bond side. If one of them has inside bound
	//side, do not remove.
	if(!tri_bond_out_domain(tris[0],L,U,dir,nb)  ||
	   !tri_bond_out_domain(tris[n-1],L,U,dir,nb) )
	    return NO;
	return YES;
}

//ref: set_increased_open_bdry_grid for 4
LOCAL void clip_intfc_at_grid_bdry1(
	INTERFACE	*intfc)
{
	INTERFACE	*cur_intfc = current_interface();
	RECT_GRID	*gr = computational_grid(intfc);
	int		dim = intfc->dim;
	int		dir, nb;
	float		L[MAXD],U[MAXD];

	DEBUG_ENTER(clip_intfc_at_grid_bdry1)
	strip_subdomain_bdry_curves(intfc);
	set_current_interface(intfc);
	for (dir = 0; dir < dim; ++dir)
	{
	    L[dir] = gr->L[dir];
	    U[dir] = gr->U[dir];
	    if (gr->lbuf[dir] == 0) L[dir] -= 0.5*gr->h[dir];
	    if (gr->ubuf[dir] == 0) U[dir] += 0.5*gr->h[dir];
	    
	    if(rect_boundary_type(intfc,dir,0) == OPEN_BOUNDARY)
	    {
		L[dir] = gr->VL[dir];
                if(debugging("ref_scat"))
		    L[dir] -= 4.0*gr->h[dir];
	    }
	    if(rect_boundary_type(intfc,dir,1) == OPEN_BOUNDARY)
	    {
		U[dir] = gr->VU[dir];
		if(debugging("ref_scat"))
		    U[dir] += 4.0*gr->h[dir];
	    }
	
	    //do not cut the reflect part
	    if(rect_boundary_type(intfc,dir,0) == REFLECTION_BOUNDARY)
		L[dir] = gr->VL[dir];
	    if(rect_boundary_type(intfc,dir,1) == REFLECTION_BOUNDARY)
		U[dir] = gr->VU[dir];
	}
	
	for (dir = 0; dir < dim; ++dir)
	{
	    for (nb = 0; nb < 2; ++nb)
	    	open_null_sides1(intfc,L,U,dir,nb);
	}
	cut_out_curves_in_buffer(intfc);
	reset_intfc_num_points(intfc);
	set_current_interface(cur_intfc);
	DEBUG_LEAVE(clip_intfc_at_grid_bdry1)
}		/*end clip_intfc_at_grid_bdry1*/


LOCAL	bool find_ending_null_side(TRI*,int,TRI**,int*);

LOCAL   bool find_ending_null_side(
        TRI *start,
        int start_side,
        TRI **tri_start,
        int *side_start)
{
	POINT	*p, *p1, **recorded_pts;
	int	num_recorded_pts;
	TRI	*next_tri, *next_tri1;
	int	i, side, side1;
	CURVE	**c;

	uni_array(&recorded_pts, MAX_NULL_SIDE, sizeof(POINT*));

	next_tri = start;
	side = start_side;
        
	num_recorded_pts = 0;
        recorded_pts[0] = Point_of_tri(start)[side];

	while(1)
	{
	    num_recorded_pts++;
	    if(num_recorded_pts > MAX_NULL_SIDE)
	    {
		printf("ERROR find_ending_null_side"
		       "too many points on the null loop.\n");
		clean_up(ERROR);
	    }

	    p = Point_of_tri(next_tri)[Next_m3(side)];
	    recorded_pts[num_recorded_pts] = p;
	    
	    //if a loop is found, return the ending tri and point.
	    for(i=0; i<num_recorded_pts; i++)
	    {
		if (recorded_pts[i] == p)
		    break;
	    }
	    if(i<num_recorded_pts)
		break;

	    side1 = side;
	    p1 = p;
	    next_tri1 = find_following_null_tri(next_tri,&p1,
	                  &side1,COUNTER_CLOCK);
	    
	    //hit another curve.
	    if (next_tri1 == NULL)
	        break;
	    
	    next_tri = next_tri1;
	    side = side1;
	}

	*tri_start = next_tri;
	*side_start = side;
	
	free(recorded_pts);
	return YES;
}


LOCAL   bool find_null_side_loop(
        INTERFACE *intfc,
        TRI *start,
        int start_side,
        TRI **tri_start,
        int *side_start)
{
        POINT *p, **recorded_pts, *ps;
        int i, j, k, num_recorded_pts,num_sides;
        TRI **null_tris, *next_tri = start;
        int *null_sides, side = start_side;
        CURVE **c;

        uni_array(&null_tris,MAX_NULL_SIDE,sizeof(TRI*));
        uni_array(&null_sides,MAX_NULL_SIDE,INT);
        uni_array(&recorded_pts,3*MAX_NULL_SIDE,sizeof(POINT*));

        num_sides = 0;
        num_recorded_pts = 0;

        recorded_pts[0] = Point_of_tri(start)[side];

        do
        {
            null_tris[num_sides] = next_tri;
            null_sides[num_sides] = side;
            ++num_sides;
            num_recorded_pts++;
            recorded_pts[num_recorded_pts] = p = Point_of_tri(next_tri)[Next_m3(side)];
            for (i = 0; i < num_recorded_pts; i++)
            {
                if (recorded_pts[i] == recorded_pts[num_recorded_pts])
                {
                    *tri_start = null_tris[i];
                    *side_start = null_sides[i];
                    free_these(3,null_tris,null_sides,recorded_pts);
                    return YES;
                }
	        ps = Point_of_tri(null_tris[i])[null_sides[i]];
		for (c = intfc->curves; c && *c; c++)
		{
		    //#bjet2
		    if(is_closed_curve(*c))
		        continue;
		    if (ps == (*c)->first->start)
		    {
		        *tri_start = null_tris[i];
		        *side_start = null_sides[i];
		        free_these(3,null_tris,null_sides,recorded_pts);
		        return YES;
		    }
		}
	    }		
	    if (p == recorded_pts[0]) break;
	    next_tri = find_following_null_tri(next_tri,&p,
	                  &side,COUNTER_CLOCK);
	    if (next_tri == NULL)
	        break;
	}
	while (next_tri != start || side != start_side);

	*tri_start = start;
	*side_start = start_side;
	free_these(3,null_tris,null_sides,recorded_pts);
	return YES;
}       /*end find_null_side_loop*/

LOCAL void merge_point_pointers_at_subdomain_bdry(
	TRI             **tris_a,
	TRI		**tris_s,
	int		nt,
	P_LINK		*p_table,
	int		p_size)
{
	POINT		*p, *ap;
	int		i, j;

        for (i = 0; i < nt; ++i)
	{
	    sorted(Point_of_tri(tris_s[i])[0]) = NO; 
	    sorted(Point_of_tri(tris_s[i])[1]) = NO;
	    sorted(Point_of_tri(tris_s[i])[2]) = NO;
	    sorted(Point_of_tri(tris_a[i])[0]) = NO; 
	    sorted(Point_of_tri(tris_a[i])[1]) = NO;
	    sorted(Point_of_tri(tris_a[i])[2]) = NO;
	}
	for (i = 0; i < nt; ++i)
	{
	    for (j = 0; j < 3; ++j)
	    {
		ap = Point_of_tri(tris_a[i])[j];
		if (sorted(ap) == NO)
		{
	            p = (POINT*)find_from_hash_table((POINTER)ap,
						     p_table,p_size);
		    if(p != Point_of_tri(tris_a[i])[j])
		        printf("#merge_point  \n");
		    
		    Point_of_tri(tris_a[i])[j] = p;
		    sorted(p) = YES;
		}
	    }
	}
}	/*end merge_point_pointers_at_subdomain_bdry*/


LOCAL	void	copy_tri_state_to_btri(
	BOND_TRI	*btri,
	BOND		*b,
	ORIENTATION	orient,
	INTERFACE	*intfc)
{
POINT		*p;
Locstate	sl, sr;
NODE		*n;
CURVE		**c;
BOND_TRI	**bt;
bool		found;
size_t	 	sizest = size_of_state(intfc);

	if (orient == POSITIVE_ORIENTATION)
	{
	    p = b->start;
	    sl = left_start_btri_state(btri);
	    sr = right_start_btri_state(btri);
	}
	else
	{
	    p = b->end;
	    sl = left_end_btri_state(btri);
	    sr = right_end_btri_state(btri);
	}

	//in install_subdomain_bdry_curve the new inserted point is always 
	//a node point.
	if ((n = node_of_point(p,intfc)) == NULL)
	{
	    ft_assign(sl,left_state(p),sizest);
	    ft_assign(sr,right_state(p),sizest);
	    /*
	    if(the_pt(Coords(p)))
	    {
		printf("#inst sub pt %d   slsr %d %d\n", p, sl, sr);
		print_general_vector("pt", Coords(p), 3, "\n");
		print_state_data(sl,intfc);
		print_state_data(sr,intfc);
	    }
	    */
	    return;
	}

	found = NO;
	//#bjet2  deal with 3 comp curve
	for(c = n->out_curves; c && *c; c++)
	{
	    if(*c == btri->curve)
	        continue;
	    found = YES;
	    for(bt=Btris((*c)->first); bt && *bt; bt++)
	        if((*bt)->surface == btri->surface)
		{
		    //printf("#ft_assign from another out curve %d\n", n);
		    ft_assign(sl, left_start_btri_state(*bt), sizest);
		    ft_assign(sr, right_start_btri_state(*bt), sizest);
		    return;
		}
	}
	
	for(c = n->in_curves; c && *c; c++)
	{
	    if(*c == btri->curve)
	        continue;
	    found = YES;
	    for(bt=Btris((*c)->last); bt && *bt; bt++)
	        if((*bt)->surface == btri->surface)
		{
		    //printf("#ft_assign from another in curve %d\n", n);
		    ft_assign(sl, left_end_btri_state(*bt), sizest);
		    ft_assign(sr, right_end_btri_state(*bt), sizest);
		    return;
		}
	}

	//Now curve is the only curve in node n
	//printf("#subdomain %d p=%d posn=%d\n", found, p, n->posn);
	if(!found)
	{
	    ft_assign(sl,left_state(p),sizest);
	    ft_assign(sr,right_state(p),sizest);
	    return;
	}

	printf("ERROR copy_tri_state_to_btri, no suitable btri found.\n");
	clean_up(ERROR);

}		/*end copy_tri_state_to_btri*/

LOCAL TRI *find_following_null_tri(
	TRI		*tri,
	POINT		**np,
	int		*side,
	ANGLE_DIRECTION dir)
{
	POINT *p;
	TRI   *newtri;
	int   nside;

	p = (dir == COUNTER_CLOCK) ? Point_of_tri(tri)[Next_m3(*side)] :
			             Point_of_tri(tri)[*side];

	newtri = tri;
	while (newtri != NULL)
	{
	    nside = Following_side_at_vertex(newtri,p,dir);
	    if (nside == ERROR)
	    {
	    	*side = -1;
	    	return NULL;
	    }
	    if (is_side_bdry(newtri,nside))
	    {
	    	if (Bond_tri_on_side(newtri,nside) == NULL)
	    	{
	    	    *side = nside;
	    	    *np = (dir == COUNTER_CLOCK) ?
	    			Point_of_tri(newtri)[Next_m3(*side)] :
	    			Point_of_tri(newtri)[*side];
	    	    return newtri;
	    	}
	    	return NULL;
	    }
	    else if (Tri_on_side(newtri,nside) == NULL)
	    {
	    	*side = nside;
	    	*np = (dir == COUNTER_CLOCK) ?
	    		Point_of_tri(newtri)[Next_m3(*side)] :
	    		Point_of_tri(newtri)[*side];
	    	return newtri;
	    }
	    newtri = Tri_on_side(newtri,nside);
	}
	return NULL;
}		/*end find_following_null_tri*/


EXPORT void strip_subdomain_bdry_curves(
	INTERFACE	*intfc)
{
	DEBUG_ENTER(strip_subdomain_bdry_curves)
	
	strip_bdry_curves(intfc, SUBDOMAIN_HSBDRY);

	DEBUG_LEAVE(strip_subdomain_bdry_curves)
}		/*end strip_subdomain_bdry_curves*/

EXPORT  void strip_bdry_curves(
	INTERFACE	*intfc,
	int		ctype)
{
	CURVE		**c;
	CURVE		**curves_to_delete = NULL;
	NODE		**nodes_to_delete = NULL;
	SURFACE		**s;
	NODE		**n;
	POINT		*p;

	for (c = intfc->curves; c && *c; ++c)
	{
	    if (hsbdry_type(*c) != ctype)
		continue;
	    for (s = (*c)->pos_surfaces; s && *s; ++s)
	    	strip_curve_from_surf(*c,*s,POSITIVE_ORIENTATION);
	    for (s = (*c)->neg_surfaces; s && *s; ++s)
	    	strip_curve_from_surf(*c,*s,NEGATIVE_ORIENTATION);
	    if (!add_to_pointers(*c,&curves_to_delete))
	    {
	    	screen("ERROR in strip_subdomain_bdry_curves(), "
	    	       "add_to_pointers() failed\n");
	    	clean_up(ERROR);
	    }
	}
	for (c = curves_to_delete; c && *c; ++c)
	    (void) delete_curve(*c);
	for (n = intfc->nodes; n && *n; ++n)
	{
	    if (!add_to_pointers(*n,&nodes_to_delete))
	    {
	    	screen("ERROR in strip_subdomain_bdry_curves(), "
	    	       "add_to_pointers() failed\n");
	    	clean_up(ERROR);
	    }
	}
	for (n = nodes_to_delete; n && *n; ++n)
	    (void) delete_node(*n);

	for (n = intfc->nodes; n && *n; ++n)
	    Boundary_point((*n)->posn) = YES;

}	//strip_bdry_curves


//it will make the Boundary_point for node to 0, it is not a problem
//(1) if the node contains only this curve, it is correct
//(2) if the node has several different curves. This case can happen when
//    node has one 3-comp curve and 3 subdomain curves and on a subdomain boundary
//    Then, in reconstruction part, the point is outside the reconstruction domain
//    in scatter_front part, the point will be cutted because it is in 
//    a subdomain boundary.
LOCAL void strip_curve_from_surf(
	CURVE		*curve,
	SURFACE		*surf,
	ORIENTATION	orient)
{
	BOND		*b;
	BOND_TRI	**btris;
	POINT		*p;
	TRI		*tri;
	int		i;
	size_t	 	sizest = size_of_state(surf->interface);
	
	DEBUG_ENTER(strip_curve_from_surf)
	for (b = curve->first; b != NULL; b = b->next)
	{
	    Boundary_point(b->start) = Boundary_point(b->end) = 0;
	    for (btris = Btris(b); btris && *btris; ++btris)
	    {
		tri = (*btris)->tri;
		for (i = 0; i < 3; ++i)
		{
		    if (Bond_tri_on_side(tri,i) == *btris)
		    {
			if(sizest > 0)
			{
			    p = (*btris)->bond->start;
			    ft_assign(left_state(p),
				left_start_btri_state(*btris),sizest);
			    ft_assign(right_state(p),
				right_start_btri_state(*btris),sizest);
			    
			    p = (*btris)->bond->end;
			    ft_assign(left_state(p),
				left_end_btri_state(*btris),sizest);
			    ft_assign(right_state(p),
				right_end_btri_state(*btris),sizest);
			}

		    	Bond_tri_on_side(tri,i) = NULL;
		    	set_side_bdry(Boundary_tri(tri),i,NO);
		    	break;
		    }
		}
		if (!delete_from_pointers(*btris,&Btris(b)))
		{
		    screen("ERROR in strip_curve_from_surf(), "
		           "delete_from_pointers() failed\n");
		    clean_up(ERROR);
		}
	    }
	}
	if (orient == POSITIVE_ORIENTATION)
	{
	    if (!(delete_from_pointers(curve,&surf->pos_curves) &&
		     delete_from_pointers(surf,&curve->pos_surfaces)))
	    {
		screen("ERROR in strip_curve_from_surf(), "
		       "delete_from_pointers() failed\n");
		clean_up(ERROR);
	    }
	}
	else
	{
	    if (!(delete_from_pointers(curve,&surf->neg_curves) &&
	    	     delete_from_pointers(surf,&curve->neg_surfaces)))
	    {
	    	screen("ERROR in strip_curve_from_surf(), "
		       "delete_from_pointers() failed\n");
		clean_up(ERROR);
	    }
	}
	DEBUG_LEAVE(strip_curve_from_surf)
}		/*end strip_curve_from_surf*/


LOCAL	INTERFACE  *cut_buf_interface1(
	INTERFACE	*intfc,
	int		dir,
	int		nb,
	int		*me,
	int		*him)
{
	INTERFACE	  *sav_intfc, *tmp_intfc, *buf_intfc;
	RECT_GRID	  *gr = computational_grid(intfc);
	RECT_GRID	  dual_gr;
	float		  L[3], U[3];
	bool		  sav_copy = copy_intfc_states();
	char              dname[1024]; 
	static const char *strdir[3] = { "X", "Y", "Z" };
	static const char *strnb[2] = { "LOWER", "UPPER" };

	DEBUG_ENTER(cut_buf_interface1)

	if (DEBUG)
	{
	    static int into[3][2];
	    (void) sprintf(dname,"fscatter/cut_buf_interface1/Into%d-%s_%s",
			   into[dir][nb],strdir[dir],strnb[nb]);
	    (void) printf("cut_buf_interface1() at ENTRY\n"
			  "  dir = %s  nb = %s  me = ( %d, %d, %d )  "
			  "him = ( %d, %d, %d )\n",
			  strdir[dir],strnb[nb],me[0],me[1],me[2],
			  him[0],him[1],him[2]);
	    summarize_interface(dname,"intfc",intfc,XY_PLANE,
				"cut_buf_interface1","intfc at ENTER");
	    ++into[dir][nb];
	}

	set_copy_intfc_states(YES);
	sav_intfc = current_interface();

	set_size_of_intfc_state(size_of_state(intfc));
	tmp_intfc = copy_interface(intfc);
	set_dual_grid(&dual_gr,gr);
	
	if (nb == 0)
	{
	    L[dir] = gr->L[dir];
	    U[dir] = gr->L[dir]+(gr->L[dir]-dual_gr.VL[dir])+0.5*gr->h[dir];
	}
	else
	{
	    L[dir] = gr->U[dir]-(dual_gr.VU[dir]-gr->U[dir])-0.5*gr->h[dir];
	    U[dir] = gr->U[dir];
	}

	open_null_sides1(tmp_intfc,L,U,dir,(nb+1)%2);

	/*
	 * Split curves that have been disconnected from surfaces
	 * and delete those sections that lie entirely within the
	 * subdomain boundary.
	 */

	cut_out_curves_in_buffer(tmp_intfc);

	reset_intfc_num_points(tmp_intfc);

	if (me[dir] == him[dir])
	{
	    buf_intfc = tmp_intfc;
	}
	else
	{
	    set_size_of_intfc_state(size_of_state(intfc));
	    buf_intfc = copy_interface(tmp_intfc);
	    (void) delete_interface(tmp_intfc);
	}
	set_copy_intfc_states(sav_copy);
	set_current_interface(sav_intfc);

	if (DEBUG)
	{
	    static int outof[3][2];
	    (void) sprintf(dname,"fscatter/cut_buf_interface1/Outof%d-%s_%s",
			   outof[dir][nb],strdir[dir],strnb[nb]);
	    summarize_interface(dname,"intfc",intfc,XY_PLANE,
				"cut_buf_interface1","intfc at EXIT");
	    summarize_interface(dname,"buf_intfc",buf_intfc,XY_PLANE,
				"cut_buf_interface1","buf_intfc at EXIT");
	    ++outof[dir][nb];
	}
	DEBUG_LEAVE(cut_buf_interface1)
	return buf_intfc;
}		/*end cut_buf_interface1*/

EXPORT	void cut_out_curves_in_buffer(
	INTERFACE	*intfc)
{
	BOND  *bs, *be;
	CURVE **c;
	NODE  **n;
	NODE  **nodes_to_delete;

	for (c = intfc->curves; c && *c; ++c)
	{
	    for (bs = (*c)->first; bs != NULL; bs = bs->next)
	        if (Btris(bs) == NULL)
		    break;
	    if (bs == NULL)
		continue;

	    for (be = bs; be->next != NULL; be = be->next)
		if (Btris(be->next) != NULL)
		    break;
	    if ((bs == (*c)->first) && (be == (*c)->last))
	    {
	        /*Entire curve is in buffer region*/
		if (!delete_curve(*c))
		{
		    screen("ERROR in cut_out_curves_in_buffer(), "
		           "can't delete curve %llu\n",curve_number(*c));
		    print_curve(*c);
		    print_interface(intfc);
		    clean_up(ERROR);
		}
		if (intfc->curves == NULL) /*No curves left*/
		    break;
		c = intfc->curves - 1;/*Start over on curve list*/
	    }
	    else if (be != (*c)->last)
	    {
	        //#bjet2  
	        //without this, the closed curve will be cutted into two connected pieces
	        //it will make an inconsistent interface after copy_interface.
	        if(is_closed_curve(*c))
	            change_node_of_closed_curve(bs->start, *c);

		if (split_curve(be->end,be,*c,NO_COMP,NO_COMP,NO_COMP,NO_COMP)
		    == NULL)
		{
		    screen("ERROR in cut_out_curves_in_buffer(), can't split "
			   "start section of curve %llu\n",curve_number(*c));
		    print_curve(*c);
		    print_interface(intfc);
		    clean_up(ERROR);
		}
		c = intfc->curves - 1;/*Start over on curve list*/
	    }
	    else if (bs != (*c)->first)
	    {
	        if(is_closed_curve(*c))
	            change_node_of_closed_curve(be->end, *c);

		if (split_curve(bs->start,bs,*c,NO_COMP,NO_COMP,NO_COMP,NO_COMP)
		    == NULL)
		{
		    screen("ERROR in cut_out_curves_in_buffer(), can't split "
			   "end section of curve %llu\n",curve_number(*c));
		    print_curve(*c);
		    print_interface(intfc);
		    clean_up(ERROR);
		}
		c = intfc->curves - 1;/*Start over on curve list*/
	    }
	}
	nodes_to_delete = NULL;
	for (n = intfc->nodes; n && *n; ++n)
	{
	    if (!add_to_pointers(*n,&nodes_to_delete))
	    {
	    	screen("ERROR in cut_out_curves_in_buffer(), "
	    	       "add_to_pointers() failed\n");
	    	clean_up(ERROR);
	    }
	}
	for (n = nodes_to_delete; n && *n; ++n)
	    (void) delete_node(*n);
}		/*end cut_out_curves_in_buffer*/

EXPORT	void communicate_default_comp(
	Front *fr)
{
	INTERFACE    *intfc = fr->interf;
	PP_GRID      *pp_grid = fr->pp_grid;
	int          me[MAXD], him[MAXD];
	int          i,j,k,dim,myid, dst_id;
	int          *G;
	bool	     status = NO;
	COMPONENT    comp_buf;
	RECT_GRID    *gr = computational_grid(intfc);
	int	     count;

	if(pp_numnodes() == 1)
	    return;
	dim = intfc->dim;
	myid = pp_mynode();
        G = pp_grid->gmax;
        find_Cartesian_coordinates(myid,pp_grid,me);

//	if (debugging("default_comp"))
	{
	    (void) printf("Entering communicate_default_comp()\n");
	    (void) printf("myid = %d\n",myid);
	    (void) printf("G = %d %d %d\n",G[0],G[1],G[2]);
	    (void) printf("me = %d %d %d\n",me[0],me[1],me[2]);
	}
	intfc->default_comp = NO_COMP;
	count = 0;
	while (pp_min_status(status) == NO)
	{
//	    if (debugging("default_comp"))
	    	(void) printf("Round %d\n",count);
	    
	    for (i = 0; i < dim; ++i)
	    {
	    	for (j = 0; j < 2; ++j)
		{
//		    if(debugging("default_comp"))
		        printf("\n#comm buf %d %d\n", i, j);
		    pp_gsync();

		    //send to adj proc
		    for (k = 0; k < dim; ++k)
		    	him[k] = me[k];
		    if (rect_boundary_type(intfc,i,j) == SUBDOMAIN_BOUNDARY)
		    {
		    	him[i] = (me[i] + 2*j - 1 + G[i])%G[i];
			dst_id = domain_id(him,G,dim);
			//xiaoxue
                        //comp_buf = buffer_component(intfc,i,j);
                        comp_buf = 3;
			if (comp_buf != NO_COMP)
			    intfc->default_comp = comp_buf;
			pp_send(0,&comp_buf,INT,dst_id);
			
//			if (debugging("default_comp"))
			{
			    (void) printf("comp_buf = %d\n",comp_buf);
			    (void) printf("Send dst_id = %d\n",dst_id);
			    (void) printf("him = %d %d %d\n",him[0],
			    		him[1],him[2]);
			    //fflush(NULL);
			}
		    }
			
		    //recv from adj proc
		    for (k = 0; k < dim; ++k)
		    	him[k] = me[k];
		    if (rect_boundary_type(intfc,i,(j+1)%2) == SUBDOMAIN_BOUNDARY)
		    {
		    	him[i] = (me[i] - 2*j + 1 + G[i])%G[i];
			dst_id = domain_id(him,G,dim);
			pp_recv(0,dst_id,&comp_buf,INT);
			if (comp_buf != NO_COMP)
			    intfc->default_comp = comp_buf;
			if (debugging("default_comp"))
			{
			    (void) printf("received comp_buf = %d\n",comp_buf);
			    (void) printf("Receive dst_id = %d\n",dst_id);
			    (void) printf("him = %d %d %d\n",him[0],
			    			him[1],him[2]);
			}
		    }
		}  //for j: side
	    }      //for i: direction

	    status = (intfc->default_comp == NO_COMP) ? NO : YES;
	    if (count++ > 100)
	    {
	    	screen("ERROR: In communicate_default_comp(): ");
		screen("default comp still unft_assigned after 100 interations\n");
		clean_up(ERROR);
	    }
	}
}	/* end communicate_default_comp */

LOCAL COMPONENT buffer_component(
	INTERFACE *intfc,
	int dir,
	int nb)
{
	RECT_GRID *gr = computational_grid(intfc);
	float *L = gr->L;
	float *U = gr->U;
	float *h = gr->h;
	float coords[MAXD];
	int i, comp;

	if (intfc->surfaces == NULL) 
	    return intfc->default_comp;
	for (i = 0; i < 3; ++i)
	    coords[i] = 0.5*(L[i] + U[i]);
	coords[dir] = (nb == 0) ? (L[dir] - 0.5*h[dir]) : 
			(U[dir] + 0.5*h[dir]);

	comp = component(coords,intfc);
	printf("in buffer_comp comp = %d\n",comp);
        if(comp == NO_COMP)
	    return intfc->default_comp;
	else
	    return comp;
        

}	/* end buffer_component */

EXPORT void install_subdomain_bdry_curves_prev(
	INTERFACE	*intfc)
{
	BOND	 *b;
	BOND_TRI *btri, *bte;
	CURVE	 *curve;
	NODE	 *ns, *ne, **n;
	POINT	 *p, *ps, *pe;
	TRI	 *tri_start, *tri_end, *start_tri;
	SURFACE	 **s;
	bool  	 sav_intrp;
	int	 side_start, side_end, start_side;
	int	 dim = intfc->dim;

	DEBUG_ENTER(install_subdomain_bdry_curves)
	sav_intrp = interpolate_intfc_states(intfc);
	interpolate_intfc_states(intfc) = NO;
	for (s = intfc->surfaces; s && *s; ++s)
	{
	    while (null_side_on_surface(*s,&start_tri,&start_side))
	    {
		find_null_side_loop(intfc,start_tri,start_side,&tri_start,&side_start);
		p = ps = Point_of_tri(tri_start)[side_start];
		if ((ns = node_of_point(ps,intfc)) == NULL)
	    	    ns = make_node(ps);
		pe = Point_of_tri(tri_start)[Next_m3(side_start)];
		if ((ne = node_of_point(pe,intfc)) == NULL)
		    ne = make_node(pe);
	    	curve = make_curve(NO_COMP,NO_COMP,ns,ne);
	    	hsbdry_type(curve) = SUBDOMAIN_HSBDRY;
	    	install_curve_in_surface_bdry(*s,curve,POSITIVE_ORIENTATION);
	    	
		printf("#c %d | %d  %d | %d  %d\n", curve_number(curve), ns, ne, ns->posn, ne->posn);

		btri = link_tri_to_bond(NULL,tri_start,*s,curve->first,curve);
	    	copy_tri_state_to_btri(btri,curve->first,POSITIVE_ORIENTATION,intfc);
	    	copy_tri_state_to_btri(btri,curve->first,NEGATIVE_ORIENTATION,intfc);

	    	tri_end = tri_start;
	    	side_end = side_start;
	    	b = curve->first;
		
		//following_null_tri uses COUNTER_CLOCK 
		//insert_point_in_bond inserts point in the end of the curve
		//the two factors result the POSITIVE orient of bond_tri

	    	while ((tri_end=find_following_null_tri(tri_end,&p,&side_end,
							COUNTER_CLOCK)) != NULL)
	    	{
		    //insert the point alread in bond, do not generate new bond_tri
		    //see second return of 
		    //i_insert_point_in_bond
		    //    split_tris_at_split_bond.
		    if (insert_point_in_bond(ne->posn,b,curve) != 
			FUNCTION_SUCCEEDED)
	            {
	                screen("ERROR in install_subdomain_bdry_curves(), "
		               "insert_point_in_bond() failed\n");
	                clean_up(ERROR);
	            }
		   
		    b = b->next;
	            ne->posn = b->end = p;
		    set_bond_length(b,dim);
	    	    btri = link_tri_to_bond(NULL,tri_end,*s,b,curve);
	            copy_tri_state_to_btri(btri,b,NEGATIVE_ORIENTATION,intfc);
	            copy_tri_state_to_btri(btri,b,POSITIVE_ORIENTATION,intfc);
		    if (ns->posn == ne->posn) //Closed loop formed
		    {
			change_node_of_curve(curve,NEGATIVE_ORIENTATION,ns);
			(void) delete_node(ne);
			break;
		    }
	        }

	    	if (is_closed_curve(curve)) 
			continue;
		
	    	b = curve->first;
		tri_end = tri_start;
		side_end = side_start;
		
		//following_null_tri uses CLOCKWISE
		//insert_point_in_bond inserts point in the start of the curve
		//the two factors result the POSITIVE orient of bond_tri

	    	while ((tri_start = find_following_null_tri(tri_start,&p,
					&side_start,CLOCKWISE)) != NULL)
	    	{
		    //new bond is inserted in b->next, the bond_tri of current bond 
		    //is saved in bte.
		    bte = Bond_tri_on_side(tri_end,side_end);
		    if (insert_point_in_bond(ns->posn,b,curve) !=
			FUNCTION_SUCCEEDED)
	            {
	                screen("ERROR in install_subdomain_bdry_curves(), "
		               "insert_point_in_bond() failed\n");
	                clean_up(ERROR);
	            }
		    
	            ns->posn = b->start = p;
		    set_bond_length(b,dim);
	            btri = link_tri_to_bond(NULL,tri_end,*s,b->next,curve);
		
		    copy_tri_state_to_btri(btri,b->next,NEGATIVE_ORIENTATION,intfc);
	            copy_tri_state_to_btri(btri,b->next,POSITIVE_ORIENTATION,intfc);
		    
		    btri = bte;
		    (void) link_tri_to_bond(btri,tri_start,*s,b,curve);
	            copy_tri_state_to_btri(btri,b,NEGATIVE_ORIENTATION,intfc);
	            copy_tri_state_to_btri(btri,b,POSITIVE_ORIENTATION,intfc);
		    tri_end = tri_start;
		    side_end = side_start;
	        }

		/*
		*       At this point the surface has run into a boundary
		*       This means there should be existing nodes with
		*       positions ns->posn and ne->posn
		*       closed curve will continue in #ccc
		*/

	    	for (n = intfc->nodes; n && *n; ++n)
	    	{
		    if (*n == ns)
			continue;
		    if ((*n)->posn == ns->posn) 
		    {
			change_node_of_curve(curve,POSITIVE_ORIENTATION,*n);
			if(!delete_node(ns))
			{
			    printf("ERROR install_subdomain_bdry_curves "
			    	   "can not delete ns node.\n");
			    print_node(ns);
			    clean_up(ERROR);
			}
			ns = *n;
			break;
		    }
	        }
	        for (n = intfc->nodes; n && *n; ++n)
	        {
		    if (*n == ne)
			continue;
		    if ((*n)->posn == ne->posn) 
		    {
			change_node_of_curve(curve,NEGATIVE_ORIENTATION,*n);
			if(!delete_node(ne))
			{
			    printf("ERROR install_subdomain_bdry_curves "
			    	   "can not delete ns node.\n");
			    print_node(ne);
			    clean_up(ERROR);
			}
			ne = *n;
			break;
		    }
	        }
	    }
	}

	for (n = intfc->nodes; n && *n; ++n)
	{
	    printf("#nd  %d %d\n", *n, (*n)->posn);
	}


	//#bjet2  two closed curves contact with each other
	//reset_nodes_posn(intfc);

	if (debugging("consistency"))
	{
	    if (!consistent_interface(intfc))
	    {
		screen("ERROR in install_subdomain_bdry_curves(), "
		       "intfc is inconsistent\n");
		clean_up(ERROR);
	    }
	}
	interpolate_intfc_states(intfc) = sav_intrp;
	DEBUG_LEAVE(install_subdomain_bdry_curves)
}		/*end install_subdomain_bdry_curves*/



#endif /* defined(THREED) */
